#!/usr/bin/env Rscript

library(testthat)
library(infercnv)

test_check("infercnv")
