This example uses an abridged version of the gencode annotations. You do not want to use that file with your own data. It's abridged here only to reduce space in R packaging.

The complete gencode annotation file can be found here:
https://github.com/broadinstitute/inferCNV_examples/tree/master/__gene_position_data

