/*
 * wf_dense.h - weighted-feature data in dense format
 *
 */
#ifndef _WF_DENSE_H_
#define _WF_DENSE_H_

typedef struct
  {
  int M;
  double *wx; // M x 2N
  double *w;  // M x 2N  (if NULL, all weights are 1's)
  double *t;  // M row weights
  double *u;  // 2N column weights
  double St2; // sum of row-weight squared (== M if all equal)
  }
wf_dense;

// if w is null, wx contains t*x (but not multiplied by u)
// if w is not null, wx = t*u*v*x


// callback functions for nnc

extern void
wf_dense_nnc_scan(
  void *data,
  int j,
  int nc,
  int *c_,
  double *Sj_
  )
;

extern void
wf_dense_nnmerge(
  void *data,
  int *n,
  int m,
  int j,
  int k
  )
;

// similarity between nodes

static inline double
wf_dense_wcov(
  void *data,
  int j,
  int k
  )
{
  wf_dense *D = (wf_dense*)data;
  int M = D->M;

  double s = 0;
  double *wxj = D->wx + M*j;
  double *wxk = D->wx + M*k;
  #pragma omp simd
  for(int i = 0; i < M; i++ )
    s += wxj[i]*wxk[i];
  if( D->w )
    {
    double sw = 0;
    double *wj = D->wx + M*j;
    double *wk = D->wx + M*k;
    #pragma omp simd
    for(int i = 0; i < D->M; i++ )
      sw += wj[i] * wk[i];
    return s / sw;
    }
  else
    return s / D->St2;
}

#endif // _WF_DENSE_H_
