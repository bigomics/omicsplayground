#include "wcov.h"

#include <math.h>

static inline void
ucentroid ( int M, real *x, const int *n, int h, int i, int j )
{
  real *xh = x + h*M;
  const real *xi = x + i*M;
  const real *xj = x + j*M;
  for(int k = 0; k < M; k++ )
    xh[k] = (n[i]*xi[k] + n[j]*xj[k])/(n[i]+n[j]);
}

static inline void
wcentroid ( int M, real *x, int h, int i, int j )
{
  real *xh = x + 2*h*M;
  const real *xi = x + 2*i*M;
  const real *xj = x + 2*j*M;
  for(int k = 0; k < 2*M; k += 2 )
    {
    xh[k] = xi[k] + xj[k];
    xh[k+1] = xi[k]*xi[k+1] + xj[k]*xj[k+1];
    if(xh[k] > 0 ) xh[k+1] /= xh[k];
    }
}


static inline void
ustdz( int M, int N, real *x )
{
  #pragma omp parallel for schedule(runtime)
  for(int i = 1; i <= N; i++)
    {
    real *xi = x + i*M;
    double ssq = 0;
    for(int k = 0; k < M; k++ )
      ssq += xi[k]*xi[k]; 
    if( ssq <= 0 ) continue;
    double s = sqrt(ssq / M);
    for(int k = 0; k < M; k++ )
      xi[k] /= s;
    }
}

static inline void
wstdz( int M, int N, real *x )
{
  #pragma omp parallel for schedule(runtime)
  for(int i = 1; i <= N; i++)
    {
    real *xi = x + 2*i*M;
    double ssq = 0, sumw = 0;
    for(int k = 0; k < 2*M; k += 2 )
      {
      double w = xi[k]*xi[k];
      sumw += w;
      ssq += w*xi[k+1]*xi[k+1]; 
      }
    if( sumw <= 0 ) continue;
    double s = sqrt(ssq / sumw);
    if( s > 0 )
      for(int k = 0; k < 2*M; k += 2 )
        xi[k+1] /= s;
    }
}
void
stdz( int W, int M, int N, real *x )
{
  if( W == 1 )
    ustdz( M, N, x );
  else if( W == 2 )
    wstdz( M, N, x );
}

void
new_centroid (
  int W, int M, real *x, const int *n,
  int h, int i, int j )
{
  if( W == 1 )
    ucentroid( M, x, n, h, i, j );
  else // W == 2
    wcentroid( M, x, h, i, j );
}


void
covscan(
  int i, 
  int nscan,
  int W,
  int M,
  const real *x,
  const int *t_id,
  double *t_S )
{
  if( W == 1 )
    {
    #pragma omp parallel for schedule(runtime)
    for(int j = 0; j < nscan; j++ )
      t_S[j] = ucov( M, x + i*M, x + t_id[j]*M );
    }
  else // if( W == 2 )
    {
    #pragma omp parallel for schedule(runtime)
    for(int j = 0; j < nscan; j++ )
      t_S[j] = wcov( M, x + 2*i*M, x + 2*t_id[j]*M );
    }
}
