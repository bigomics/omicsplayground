/*
 * nclustree.c
 *
 * Various functions for handling nclust tree data structure.
 *
 * The binary tree is represented by three integer index links per node:
 * U(p), L(eft) and R(ight). This is a doubly-linked binary tree.
 *
 * - The zero-eth node is a dummy node.
 * - L[0] == R[0] is the root. U[0] == 0.
 * - The root point to zero as the parent.
 * - The leaves point to zero as their left and right children.
 *
 * Empty and singleton tree is possible.
 *
 * For a tree with N nodes, the length of link arrays is 2*N.
 *
 * nclust uses index 1:N for leaf nodes, and the root is always the
 * last node (index: 2*N-1).
 *
 * Depth-first tree traversal can be done without recursion nor stack.
 * The doubly-linked tree allows state-machine
 * iteration using a "stack" implicit in the links.
 * The `state` keeps track the stage of the visits.
 *
 */
#include <stdlib.h>
#include <stdio.h> // debugging only

#include "nclustree.h"
#include "wcov.h"

#ifndef SHELLPROG 
  #include <R.h> // for Rprintf
  #define mess(...) Rprintf(__VA_ARGS__)
#else
  #define mess(...) fprintf(stderr,__VA_ARGS__)
#endif
/*
 * given a binary tree, returns the ordering of the leaves and
 * the left-most leaf of each cluster.
 */

void
leafordering( 
  const int *U,
  const int *L,
  const int *R,
  int *order,
  int *leftmost )
{
  int r = 0;    // index to 'order'
  int p = 0; // previous node

  for(int i = R[0]; i; )
    {
    if( p == U[i] ) // arrive from parent
      {
      if( L[i] == 0 ) // in a leaf node
        {
        order[r] = i;
        leftmost[i] = r;
        r++;
        
        p = i;
        i = U[i]; // return to parent
        }
      else
        {
        p = i;
        i = L[i]; // visit left node
        }
      }
    else if( p == L[i] ) // coming back from the left
      {
      p = i;
      i = R[i];  // visit the right node
      }
    else // coming back from the right
      {
      leftmost[i] = leftmost[ L[i] ];
      
      p = i;
      i = U[i]; // return to parent
      }
    }
}

/*
 * nearest nephew branch flipping
 *
 */
void
nearestnephew(
  const int *U,
  int *L,
  int *R,

  int M, // data dimensionality
  int W, // 1: unweighted, 2: weighted
  const real *x)
{
  if( L[L[0]] == 0 ) return; // singleton

  int p = 0; // previous node
  for(int i = R[0]; i; )
    {
    if( p == U[i] )
      {
      if( L[i] == 0 || L[L[i]] == 0 ) // skip to the right node
        {
        p = L[i];
        continue;
        }
      
      double S_LL_R = (W == 1 ?
          ucov(M, x + M * L[L[i]], x + M * R[i] ) :
          wcov(M, x + 2*M * L[L[i]], x + 2*M * R[i] ) );
      double S_LR_R = (W == 1 ? 
          ucov(M, x + M * R[L[i]], x + M * R[i] ) :
          wcov(M, x + 2*M * R[L[i]], x + 2*M * R[i] ) );

      if( S_LL_R > S_LR_R )
        SWAP(int, L[L[i]], R[L[i]] );

      p = i;
      i = L[i];
      }
    else if( p == L[i] )
      {
      if( R[i] == 0 || L[R[i]] == 0 )
        {
        p = i;
        i = U[i];
        continue;
        }

      double S_L_RL = (W == 1 ?
          ucov(M, x + M * L[i], x + M * L[R[i]] ) :
          wcov(M, x + 2*M * L[i], x + 2*M * L[R[i]] ) );
      double S_L_RR = (W == 1 ? 
          ucov(M, x + M * L[i], x + M * R[R[i]] ) :
          wcov(M, x + 2*M * L[i], x + 2*M * R[R[i]] ) );

      if( S_L_RL < S_L_RR )
        SWAP(int, L[R[i]], R[R[i]] );

      p = i;
      i = R[i];
      }
    else // if( p == R[i] )
      {
      p = i;
      i = U[i];
      }
    }
}

/*
 * nearest-nephew branch flipping method
 * 
 * This is a version using callback
 */
void
branchflip_nnephew(
  const int *U,
  int *L,
  int *R,

  void *data,
  double (sim)(void *data, int j, int k)
  )
{
  if( L[L[0]] == 0 ) return; // singleton

  int p = 0; // previous node
  for(int i = R[0]; i; )
    {
    if( p == U[i] )
      {
      if( L[i] == 0 || L[L[i]] == 0 ) // skip to the right node
        {
        p = L[i];
        continue;
        }

      double S_LL_R = sim(data,L[L[i]],R[i]);
      double S_LR_R = sim(data,R[L[i]],R[i]);
      
      if( S_LL_R > S_LR_R )
        SWAP(int, L[L[i]], R[L[i]] );

      p = i;
      i = L[i];
      }
    else if( p == L[i] )
      {
      if( R[i] == 0 || L[R[i]] == 0 )
        {
        p = i;
        i = U[i];
        continue;
        }

      double S_L_RL = sim(data,L[i],L[R[i]]);
      double S_L_RR = sim(data,L[i],R[R[i]]);

      if( S_L_RL < S_L_RR )
        SWAP(int, L[R[i]], R[R[i]] );

      p = i;
      i = R[i];
      }
    else // if( p == R[i] )
      {
      p = i;
      i = U[i];
      }
    }
}

/*
 * dendrocoord.c - convert nclust tree and scores to coordinates for line plots
 *
 */

void
dendrocoord (
  const int *U, const int *L, const int *R, const double *S,
  const int *leftmost, const int *n,
  const int *nprune,   // branches with < n leaves are pruned
  const int *stemtype,  // 0: none, 1: relative, 2: absolute, 3: S[]
  const double *stemlength,
  double *x, double *y, int *npoints )  // max: 2*3*(N-1) + N
{
  int j = 0; // index to x and y coord   
  
  int p = 0;
  for( int i = R[0]; i; )
    {
    if( p == U[i] )
      {
      if( L[i] == 0 || n[i] <= *nprune )
        {
        if( *stemtype == 1 )
          {
          x[j] = leftmost[i] + 0.5*n[i]; y[j] = S[U[i]] + *stemlength; j++;
          }
        else if( *stemtype == 2 )
          {
          x[j] = leftmost[i] + 0.5*n[i]; y[j] = *stemlength; j++;
          }
        else if( *stemtype == 3 )
          {
          x[j] = leftmost[i] + 0.5*n[i]; y[j] = S[i]; j++;
          } 
        
        p = i;
        i = U[i];
        continue;
        } 

      x[j] = leftmost[i] + 0.5*n[i]; y[j] = S[i]; j++;
      x[j] = leftmost[L[i]] + 0.5*n[L[i]]; y[j] = S[i]; j++;
      p = i;
      i = L[i];
      }
    else if( p == L[i] )
      {
      x[j] = leftmost[L[i]] + 0.5*n[L[i]]; y[j] = S[i]; j++;
      x[j] = leftmost[R[i]] + 0.5*n[R[i]]; y[j] = S[i]; j++;
      p = i;
      i = R[i];
      }
    else // if( p == R[i] )
      {
      x[j] = leftmost[R[i]] + 0.5*n[R[i]]; y[j] = S[i]; j++;
      x[j] = leftmost[i] + 0.5*n[i]; y[j] = S[i]; j++;
      p = i;
      i = U[i];
      }
    }
  *npoints = j;
}

// tree subset, modify in place
void
nclustree_subset (
  int *U,
  int *L,
  int *R,
  double *S,
  const int *z,        // subset indicator: if 0,  delete
  int *Nnew_           // new number of leaves
  )
{
  //
  // First pass: flag deleted leaves and respective parents, relink to
  // siblings
  //
  int i, Nnew = 0;
  for(i = 1; L[i] == 0 ; i++ ) // loop over leaves
    {
    if( z[i] )
      {
      Nnew++;
      continue;
      }
    int parent = U[i];
    int grandparent = U[parent];
    int sibling = (L[parent] == i ? R[parent] : L[parent]);
    int *C = (L[grandparent] == parent ? L : R );

    U[sibling] = grandparent;
    C[grandparent] = sibling;
    U[i] = U[parent] = -1;    // flag self and parent as deleted
    }

  //
  // Compact the nodes numbering
  //
  int N = i;
  int *i2j = (int*)calloc(2*N, sizeof(int));
  int j;
  for(j = 0, i = 0; i < 2*N; i++ )
      if( U[i] != -1 )
        i2j[i] = j++;
  
  // only for debug?
  if( j != 2*Nnew ) 
    { mess("j != 2*Nnew\n"); goto END; }
  
  for(i = 0; i < 2*N; i++ )
    {
    if(U[i] == -1 ) continue;
    j = i2j[i];
    U[j] = i2j[U[i]];
    L[j] = i2j[L[i]];
    R[j] = i2j[R[i]]; 
    S[j] = S[i];
    }

END:
  *Nnew_ = Nnew;
  free(i2j);
  return;
}
