/*
 * topq.h - priority queue data structure to keep top-scoring neighbors
 *
 */

#ifndef _TOPQ_H_
#define _TOPQ_H_

#ifndef SWAP
#define SWAP(type,x,y) do{ type t=(x);(x)=(y);(y)=t; } while(0)
#endif

/*

Priority queue for the top-scoring K neighbors

- item at index 0 is the best (maximum)
- item at index 1 is (one of) the worst (minimum)
- the remaining are nodes of a heap tree, where the children are
  no worse than the parent 

Data structure:
- K is the queue length (including the zero-eth element)
- id is the node id of item in the queue
- S is the score 

*/

// Remove items where flag[id[.]] == 0, shift the data to compact.
// Return the number of items remaining.
static inline int
topq_compact ( int K, int *id, double *S, const int *flag )
{
  int i = 0;
  for(int j = 0; j < K; j++ )
    if( flag[ id[j] ] == 0 ) 
      {
      id[i] = id[j];
      S[i] = S[j];
      i++;
      }
  return i;
}

// Rearrange items already in place (but not structured)
// such that the heap conditions are satisfied (with max at 0, min at 1)
//
static inline void
topq_heapify ( int K, int *id, double *S )
{
  for(int i = 1; i < K; i++ )
    {
    if( S[i] > S[0] ) // if larger than the max, swap
      {
      SWAP(int, id[0], id[i]);
      SWAP(double, S[0], S[i]);
      }
      
    int idi = id[i];
    double Si = S[i];

    int j = i;
    for(int k = j/2; k > 0 && S[k] > Si; k /= 2 )
      {
      id[j] = id[k];
      S[j] = S[k];
      j = k;
      }

    id[j] = idi;
    S[j] = Si;
    }
}

// Push an item into a queue 
static inline void
topq_push ( int K, int *id, double *S, int j, double Sj )
{
  if( Sj < S[1] ) // smaller than the smallest, skip
    return;

  if( Sj > S[0] ) // larger than the largest
    {
    id[1] = id[0]; S[1] = S[0]; // discard the smallest
    id[0] = j; S[0] = Sj;       // new item is the largest
    j = id[1]; Sj = S[1];
    }

  // downheap to find the right place for the root
  int i = 1;
  for(int k = 2; k < K; k *= 2 )
    {
    if( (k+1 < K ) && (S[k] > S[k+1]) )
      k++;

    if( Sj <= S[k] )
      break;

    id[i] = id[k]; S[i] = S[k];
    i = k;
    }
  id[i] = j; S[i] = Sj;
}


#endif
