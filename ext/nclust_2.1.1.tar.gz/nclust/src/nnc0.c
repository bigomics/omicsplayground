/*
 * nnc0.c - nearest-neighbor chain algorithm for hierarchical clustering
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "nclustree.h"
#include "wcov.h"
#include "topq.h"

// If used as R library (default), use R's way to output to console.
// This also allows control-C in R prompt to abort execution.
//
#ifndef SHELLPROG 
  #include <R.h> // for Rprintf
  #define mess(...) Rprintf(__VA_ARGS__)
#else
  #define mess(...) fprintf(stderr,__VA_ARGS__)
#endif

/* TODO 
- factor out nnc regardless of the (un)weighted data
  and clustering criteria. 
- nnc can work with moment or LWJ recurrence. should both be supported
  and be abstracted also? In principle, these are hidden from NNC.
- choice of minimization versus maximization as an option? Can be trivially
  done by negating the scoring function.
*/

/*
Data format

Node indices:
0 dummy (unused)
1:N leaf nodes
(N+1):(2N-1) internal (branch/cluster) nodes

L, R, and U are vectors of indices to Left child, Right child
and Up (parent) nodes.

The dummy node (index 0) is used as the children of the leaf
nodes and the parent of the root.

*/
void
nnc0
  (
  const int *dim, // [3] array dimensions: W x M x N
  real *x,        // [dim[0]*dim[1]*2*N] leaf and cluster data vectors 

  int *L,         // [2*N] left child
  int *R,         // [2*N] right child
  int *U,         // [2*N] parent

  double *S,      // [2*N] node similarity score
  int *order,     // [N] leaf order
  int *n,         // [2*N] number of leafs in a cluster
  int *leftmost,  // [2*N] leftmost leaf (0-based index to 'order')
  int *level,     // [2*N] node level: root is zero, its child is one, etc.

  const int *options, // [4] see below
  int *retstat        // [1] return status: 0 Ok, -1 malloc failed.
  )
{
  int W = dim[0];  // W==1 value only data, W==2 (weight,value) pairs
  int M = dim[1];  // number of features 
  int N = dim[2];  // number of objects

  int K = options[0];           // maximum queue length
  int branchflip = options[1];  // branchflip method
  int standardize = options[2]; // standardize the data vectors 
  int verbose = options[3]; // verbose level

  // Allocate the chain with queue and temporary storage
  int *t_id = (int*) malloc( sizeof(int) * N * (4 + K) );
  if( t_id == NULL )
    { *retstat = -1; return; }
  int *topq_id = t_id + N;
  int *c_id = topq_id + N * K;
  int *c_nxbr = c_id + N;
  int *c_qlen = c_nxbr + N;
  double *t_S = (double*) malloc( sizeof(double) * N * (1+K) );
  if( t_S == NULL )
    { *retstat = -1; return; }
  double *topq_S = t_S + N;

  // Intialize the tree
  for(int i = 1; i <= N; i++ ) // leaf nodes in free list
    {
    U[i] = 0;
    L[i] = i-1;
    R[i] = i+1;
    }

  L[1] = R[N] = 0;  // dummy at both ends
  L[0] = N;
  R[0] = 1;

  for(int i = N+1; i < 2*N; i++ ) // branch nodes
    U[i] = L[i] = R[i] = 0;

  // Initialize leaf counts
  n[0] = 0;
  for(int i = 1; i <= N; i++)
    n[i] = 1;

  if( standardize )
    stdz( W, M, N, x );

#define PROGRESS_GRAIN 0.005 
  double progress = PROGRESS_GRAIN;
  time_t t0 = time(NULL);
  clock_t clock0 = clock();
  if( verbose & 0x1 )
    {
    mess("Number of items: %d, number of features: %d, %s\n\n",
      N, M, W == 1 ? "unweighted" : "densely weighted");
    mess("%-15s%-20s%-10s%20s%14s\n",
        "time elapsed:","0%","   50%","100%","time left:");
    }

  //
  // The Thing
  //
  int qempty = 0;   // number of times the queue is emptied
  int qhit = 0;     // number of times NN is found on the queue
  int newscans = 0; // number of times new scans need to be performed

  int nxch = 0;    // next chain position (and chain length)

  for( int nxbr = N+1; nxbr < 2*N; nxbr++ ) // tree-building loop
    {
    if( nxch == 0 )   // chain is empty: move a free node to the chain
      {
      int i = R[0];   // next free node

      R[0] = R[i];    // unlink node i from the top of free list
      L[R[0]] = 0;    // back-link
      R[i] = 0;       // reset; L[i] is already zero

      c_id[nxch] = i;    // put i into the chain
      c_qlen[nxch] = 0;  // indicate the queue is empty
      nxch++;
      }
    else  // refresh queue of the last node in the chain
      {
      // compact the queue: remove bound nodes 
      int z = nxch - 1;
      int *idz = topq_id + z*K;
      double *Sz = topq_S + z*K;

      c_qlen[z] = topq_compact ( c_qlen[z], idz, Sz, U );

      if( c_qlen[z] > 0 ) // queue not empty after compacting
        {
        topq_heapify ( c_qlen[z], idz, Sz );

        // scan new branches created after the queue last update
        int nscan = 0;
        for(int i = c_nxbr[z]; i < nxbr; i++ )
          if( U[i] == 0 )
            t_id[nscan++] = i;

        covscan( c_id[z], nscan, W, M, x, t_id, t_S );

        for(int i = 0; i < nscan; i++ )
          topq_push( c_qlen[z], idz, Sz, t_id[i], t_S[i] ); 

        c_nxbr[z] = nxbr;
        }
      else
        qempty++;
      }

    // extend the chain until a merge condition encountered
    for(;;)
      {
      int z = nxch - 1;
      int *idz = topq_id + z*K;
      double *Sz = topq_S + z*K;

      // if the queue is empty, compare all free nodes and fill-in 
      if( c_qlen[z] == 0 )
        {
        newscans++;
        Sz[0] = -INFINITY; // sentinel, for when there is no more free nodes

        // check all free nodes
        int nscan = 0;
        for(int j = R[0]; j; j = R[j] )
          t_id[nscan++] = j;

        covscan( c_id[z], nscan, W, M, x, t_id, t_S ); 

        // put into queue
        c_qlen[z] = (nscan < K ? nscan : K );
        for(int i = 0; i < c_qlen[z]; i++ )
          {
          idz[i] = t_id[i];
          Sz[i] = t_S[i];
          }
        topq_heapify ( c_qlen[z], idz, Sz );

        if( nscan > c_qlen[z] )
          for(int i = c_qlen[z]; i < nscan; i++ )
            topq_push( c_qlen[z], idz, Sz, t_id[i], t_S[i] );

        c_nxbr[z] = nxbr;
        }
      else
        qhit++;

      if(verbose & 0x8 ) // print out the NN chain
        {
        for(int i = 0; i < nxch; i++ )
          mess("chain %d: %d %d %g\n",
              i, c_id[i], topq_id[i*K], topq_S[i*K] );
        }

      // check for reciprocal NN
      if ( nxch >= 2 && topq_S[(nxch-2)*K] >= topq_S[(nxch-1)*K] )
        break;

      // append the nearest to the chain

      int j = idz[0];

      if( verbose & 0x4 )   // print out chain extension
        mess("    extend %d: %d ~ %d (%g)\n",
          nxch-1, c_id[nxch-1], topq_id[ (nxch-1)*K], topq_S[(nxch-1)*K] );

      // unlink from free-node list
      L[ R[j] ] = L[j];
      R[ L[j] ] = R[j];
      L[j] = R[j] = 0;

      // append to the chain
      c_id[nxch] = j;
      c_qlen[nxch] = 0;

      nxch++;
      }

    // merge that last two nodes on the chain
    int h = nxbr;
    int i = c_id[nxch-2];
    int j = c_id[nxch-1];

    if(verbose & 0x2 ) // print out pairs to be merged
      mess("  merge: %d %d -> %d\n\n", i, j, h);

    U[i] = U[j] = h; // new node is parent of the merge ones

    n[h] = n[i] + n[j]; // number of leafs in the cluster

    new_centroid( W, M, x, n, h, i, j );

    S[h] = topq_S[(nxch-2)*K];

    // put the new branch node in free-node list
    R[h] = R[0];
    L[R[h]] = h;
    R[0] = h;
    L[h] = 0;

    nxch -= 2; // pop

    if(verbose & 0x1) // progress bar
      {
      double m = nxbr-N;
      double completed_frac = (m*(N-0.5*(m+1)))/((double)N*(N-1)/2);
      if( completed_frac > progress )
        {
        progress += PROGRESS_GRAIN;
        int elapsed = difftime( time(NULL), t0);
        mess("\r%4dh %2dm %2ds  ",
           elapsed/3600,(elapsed % 3600)/60,elapsed % 60 );
        for(int i = 0; i < 50; i++ )
          mess( "%c", i < floor(completed_frac*50) ? '#':'-');
        int remaining = round((elapsed/completed_frac)*(1-completed_frac));
        mess(" %4dh %2dm %2ds", 
            remaining / 3600, (remaining % 3600)/60, remaining % 60 );
        }
      }
    } // end of NNC algorithm

  if(verbose & 0x1)
    {
    int elapsed = difftime( time(NULL), t0);
    mess("\r%4dh %2dm %2ds  ",
       elapsed/3600,(elapsed % 3600)/60,elapsed % 60 );
    mess("##################################################              \n");
    clock_t clock_now = clock();
    int cput = round((clock_now - clock0)/CLOCKS_PER_SEC);
    mess("%14s\n","CPU time:");
    mess("%4dh %2dm %2ds\n",
        cput/3600, (cput % 3600)/60, cput % 60 );
    mess("new scans  = %d, queue hits = %d, queue empty = %d\n\n",
        newscans, qhit, qempty );
    }

  // fill-in L and R (all are zeroes by now, only U represent the tree)
  for(int i = 1; i < 2*N-1; i++ )
    {
    int j = U[i];

    if( L[j] == 0 ) // fill in the left first
      L[j] = i;
    else
      R[j] = i;
    }

  //===============

  // branch flipping method. Default to the original NN-chain order.
  if( branchflip == 0 ) // nearest nephew
    {
    if( S[ L[R[0]] ] < S[ R[R[0]] ] ) // arbitrary rule for the root
      SWAP(int, L[R[0]], R[R[0]] );

    nearestnephew( U, L, R, M, W, x );
    }
  else if( branchflip == 1 ) // tight left
    {
    for(int i = N; i < 2*N; i++ )
      if( S[ L[i] ] < S[ R[i] ] || (L[L[i]] && !L[R[i]] ))
        SWAP(int, L[i], R[i] );
    }
  else if( branchflip == 2 ) // tight right
    {
    for(int i = N; i < 2*N; i++ )
      if( S[ L[i] ] > S[ R[i] ] || (!L[L[i]] && L[R[i]] ))
        SWAP(int, L[i], R[i] );
    }

  level[2*N-1] = 0;               // root is level 0
  for(int i = 2*N-2; i; i-- )
    level[i] = level[U[i]] + 1;

  leafordering( U, L, R, order, leftmost );

  free(t_id);
  free(t_S);
  *retstat = 0;
  return;
}
