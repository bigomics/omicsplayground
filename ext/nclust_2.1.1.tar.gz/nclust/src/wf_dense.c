/*
 * wf_dense.c - dense weighted matrix data structure for nnc
 *
 */

#include <stdlib.h>

#include "wf_dense.h"

void
wf_dense_nnc_scan(
  void *data,
  int j,
  int nc,
  int *c_,
  double *Sj_
  )
{
  wf_dense *D = (wf_dense*)data;
  const int M = D->M;

  const double *wxj = D->wx + M*j;
  #pragma omp parallel for schedule(runtime)
  for(int k = 0; k < nc; k++ )
    {
    const double *wxk = D->wx + M*c_[k];
    double s = 0;
    #pragma omp simd
    for(int i = 0; i < M; i++ )
      s += wxj[i] * wxk[i];
    Sj_[k] = s;
    }

  if( D->w )
    {
    const double *wj = D->w + M*j;
    #pragma omp parallel for schedule(runtime)
    for(int k = 0; k < nc; k++ )
      {
      const double *wk = D->w + M*c_[k];
      double s = 0;
      #pragma omp simd
      for(int i = 0; i < M; i++ )
        s += wj[i] * wk[i];
      Sj_[k] /= s;
      }
    }
  else
    {
    for(int k = 0; k < nc; k++ )
      Sj_[k] /= D->St2;
    }

  return;
}

void
wf_dense_nnmerge(
  void *data,
  int *n,
  int m,
  int j,
  int k
  )
{
  wf_dense *D = (wf_dense*)data;
  const int M = D->M;
  
  if( D->w )
    {
    double *wxj = D->wx + M*j, *wj = D->w + M*j;
    double *wxk = D->wx + M*k, *wk = D->w + M*k;
    double *wxm = D->wx + M*m, *wm = D->w + M*m;
    
    D->u[m] = D->u[j] + D->u[k];
    for(int i = 0; i < M; i++ )
      {
      wxm[i] = wxj[i] + wxj[k];
      wm[i] = wm[j] + wm[k];
      }
    }
  else
    {
    double *txj = D->wx + M*j;
    double *txk = D->wx + M*k;
    double *txm = D->wx + M*m;
    double uj = D->u[j];
    double uk = D->u[k];
    double um = uj + uk;
    D->u[m] = um;

    for(int i = 0; i < M; i++ )
      txm[i] = (uj * txj[i] + uk *txk[i])/um;
    }
}
