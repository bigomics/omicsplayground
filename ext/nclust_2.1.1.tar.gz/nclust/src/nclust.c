/*
 * nclust.c - hierarchical clustering using asymmetrically weghted covariance
 *
 * - abstract data type (dense/sparse, float/double, dataset grid)
 * - fast I/O (from R, or directly from file)
 * - pre-processing: centering, scaling, tree allocation
 * - post-processing: branch re-ordering, tree stats (level, leftmost, nleaves)
 */


// first prototype: mimic nnc0.c
void 
nclust0(
  )
{
  
  // input (file or R object)
 
  // pre-proc (double centering and scaling)

  // post-proc (nearest-nephew reordering, tree stat)

}

// second prototype: float? direct I/O
