/*
 * nnc_dense.c - nearest-neighbor chain using dense data matrix
 *
 * test dummy for transitioning to callback
 *
 */

#include "nnc.h"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "nclustree.h"
#include "wcov.h"
#include "topq.h"

// If used as R library (default), use R's way to output to console.
// This also allows control-C in R prompt to abort execution.
//
#ifndef SHELLPROG 
  #include <R.h> // for Rprintf
  #define mess(...) Rprintf(__VA_ARGS__)
#else
  #define mess(...) fprintf(stderr,__VA_ARGS__)
#endif

/*
Data format

Node indices:
0 dummy (unused)
1:N leaf nodes
(N+1):(2N-1) internal (branch/cluster) nodes

L, R, and U are vectors of indices to Left child, Right child
and Up (parent) nodes.

The dummy node (index 0) is used as the children of the leaf
nodes and the parent of the root.

*/

typedef struct {
  int W;
  int M;
  double *x;
}
data_dense;

void nncscan_dense (
  void *data_,
  int A,
  int nB,
  int *B_,
  double *SAB_
  )
{
  data_dense *data = (data_dense*)data_;
  covscan( A, nB, data->W, data->M, data->x, B_, SAB_ );
}

void nncmerge_dense (
  void *data_,
  int *n,
  int A,
  int B,
  int C
  )
{
  data_dense *data = (data_dense*)data_;

  new_centroid( data->W, data->M, data->x, n , C, A, B );
}


void
nnc_dense
  (
  const int *dim, // [3] array dimensions: W x M x N
  real *x,        // [dim[0]*dim[1]*2*N] leaf and cluster data vectors 

  int *L,         // [2*N] left child
  int *R,         // [2*N] right child
  int *U,         // [2*N] parent

  double *S,      // [2*N] node similarity score
  int *order,     // [N] leaf order
  int *n,         // [2*N] number of leafs in a cluster
  int *leftmost,  // [2*N] leftmost leaf (0-based index to 'order')
  int *level,     // [2*N] node level: root is zero, its child is one, etc.

  const int *options, // [4] see below
  int *retstat        // [1] return status: 0 Ok, -1 malloc failed.
  )
{
  const int W = dim[0];
  const int M = dim[1];
  const int N = dim[2];

  const int K = options[0];
  const int branchflip = options[1];
  const int standardize = options[2];
  const int verbose = options[3];

  // standardize the data
  if(standardize)
    stdz( W, M, N, x );

  data_dense data = { W, M, x };

  nnc( N, &data, nncscan_dense, nncmerge_dense, L, R, U, S, n, K, verbose );

  // branch flipping method. Default to the original NN-chain order.
  if( branchflip == 0 ) // nearest nephew
    {
    if( S[ L[R[0]] ] < S[ R[R[0]] ] ) // arbitrary rule for the root
      SWAP(int, L[R[0]], R[R[0]] );

    nearestnephew( U, L, R, M, W, x );
    }
  else if( branchflip == 1 ) // tight left
    {
    for(int i = N; i < 2*N; i++ )
      if( S[ L[i] ] < S[ R[i] ] || (L[L[i]] && !L[R[i]] ))
        SWAP(int, L[i], R[i] );
    }
  else if( branchflip == 2 ) // tight right
    {
    for(int i = N; i < 2*N; i++ )
      if( S[ L[i] ] > S[ R[i] ] || (!L[L[i]] && L[R[i]] ))
        SWAP(int, L[i], R[i] );
    }

  level[2*N-1] = 0;               // root is level 0
  for(int i = 2*N-2; i; i-- )
    level[i] = level[U[i]] + 1;

 
  // other tree auxiliary info
  leafordering( U, L, R, order, leftmost );

  *retstat = 0;
  return;
}
