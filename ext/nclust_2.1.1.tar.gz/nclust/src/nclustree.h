
#ifndef _NCLUSTREE_H_
#define _NCLUSTREE_H_

#ifndef SWAP
#define SWAP(type,x,y) do{ type t=(x);(x)=(y);(y)=t; } while(0)
#endif

/*
 * given a binary tree, returns the ordering of the leaves and
 * the left-most leaf of each cluster.
 */

void
leafordering( 
  const int *U,
  const int *L,
  const int *R,
  int *order,
  int *leftmost )
;


#include "wcov.h"  // for `typedef ... real;`

/*
 * nearest newphew branch flipping
 *
 */
void
nearestnephew(
  const int *U,
  int *L,
  int *R,
  int M,
  int W,
  const real *x)
;

void
branchflip_nnephew(
  const int *U,
  int *L,
  int *R,

  void *data,
  double (sim)(void *data, int j, int k)
  )
;

/*
 * dendrogram geometric coordinates from a tree
 */
void
dendrocoord (
  const int *U, const int *L, const int *R, const double *S,
  const int *leftmost, const int *n,
  const int *nprune,   // branches with < n leaves are pruned
  const int *stemtype,  // 0: none, 1: relative, 2: absolute, 3: S[]
  const double *stemlength,
  double *x, double *y, int *npoints )  // max: 2*3*(N-1) + N
;

// tree subset, modify in place
void
nclustree_subset (
  int *U,
  int *L,
  int *R,
  double *S,
  const int *z,        // subset indicator: if 0,  delete
  int *Nnew_             // new number of leaves
  )
;

#endif // _NCLUSTREE_H_
