#ifndef _NNC_H_
#define _NNC_H_

extern int    // 0: ok, -1: malloc failure
nnc (

  // data input
  const int N,        // number of items
  void *data,         // data object, to be passed on to callback functions
  void (*nnc_scan)(   // callback to fill-in S
    void *data,
    int A,            // cluster id
    int nB,           // number of B's to check against A
    int *B_,          // list of B's
    double *SAB_      // returned S(A,B)
    ),
  void (*nnc_merge)(  // callback to merge A and B into C
    void *data,
    int *n,
    int A,
    int B,
    int C
    ),

  // tree output, storage allocated by caller
  int *L,             // [2*N] left child
  int *R,             // [2*N] right child
  int *U,             // [2*N] up (parent)
  double *S,          // [2*N] cluster score (tree height)
  int *n,             // [2*N] number of leafs
  
  // nnc specific options
  int K,               // maximum queue length
  int verbose
  );

#endif // _NNC_H_
