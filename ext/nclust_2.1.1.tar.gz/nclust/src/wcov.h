/*
 * wcov.h
 *
 * average link of weighted covariance
 *
 * - so far, only for dense, double precision matrix data, optionally
 *   with default weight equals to one for all
 *
 */


#ifndef _WCOV_H_
#define _WCOV_H_

typedef double real; // [!] don't forget to modify .C() in ../R/nnc.R

#include <math.h>

// standardize item vector
//
extern void
stdz( int W, int M, int N, real *x )
;

// 1-weighted covariance
static inline double
ucov (
  int M,
  const real *xi,
  const real *xj )
{
  double sxx = 0;
  #pragma omp simd
  for(int k = 0; k < M; k++ )
    sxx += xi[k] * xj[k];
  return sxx / M;
}

// weighted covariance
static inline double
wcov (
  int M,
  const real *xi,
  const real *xj )
{
  double swwxx = 0, sww = 0;
  #pragma omp simd
  for(int k = 0; k < 2*M; k += 2 )
    {
    double ww = xi[k] * xj[k];
    sww += ww;
    swwxx += ww * xi[k+1] * xj[k+1];
    }
  return sww > 0 ? swwxx / sww : 0;
}

// scan covariance of items in t_id againtst x[i], return the results
// in t_S
extern void
covscan(
  int i, 
  int nscan,
  int W,
  int M,
  const real *x,
  const int *t_id,
  double *t_S )
;

extern
void
new_centroid (
  int W, int M, real *x, const int *n,
  int h, int i, int j )
;

#endif // _WCOV_H_
