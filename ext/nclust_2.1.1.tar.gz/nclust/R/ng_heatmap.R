require(grDevices)

red.white.blue <- c(              
          hsv(.666,seq(1,.1,-.1),1),       # blue-to-white  (-1 to 0)
          "#FFFFFF",                       # white == 0
          hsv(0,seq(.1,1,.1),1))           # white-to-red  (0 to +1)

red.black.green <- c(              
          hsv(.333,1,seq(1,.1,-.1)),       # blue-to-white  (-1 to 0)
          "#000000",                       # white == 0
          hsv(0,1,seq(.1,1,.1)))           # white-to-red  (0 to +1)

yellow.black.blue <- c(
          hsv(.666,1,seq(1,.1,-.1)),       # blue-to-white  (-1 to 0)
          "#000000",                       # white == 0
          hsv(.1666,1,seq(.1,1,.1)))           # white-to-red  (0 to +1)

black.gray.white <- gray( seq(1,0,-.05))

ng_heatmap <- function(
  x,
  ro,   # row subset and ordering (indices or names)
  co,   # column subset and ordering (indices or names)
  rbin=1, cbin=10, # size of row and column bins for local averaging
  saturation=1,
  hcol=red.white.blue,
  rwb = nrow(x), cwa = 1
  )
{
  h <- tilemean(x, irow=ro, icol=co, tilesize=c(rbin,cbin) )

  nc <- length(hcol)
  rh <- hcol[ nc %/% 2 + 1 + floor( (nc-1)/ 2 * tanh(saturation*h)) ]
  dim(rh) <- dim(h)

  pushViewport(viewport(
      xscale=c(cwa - 0.5, cwa + length(co) + (cbin-length(co))%% cbin + 0.5 ),
      yscale=c(rwb + 0.5, rwb -( -0.5 + length(ro) + (rbin-length(ro)) %% rbin))
      ))

  grid.raster( rh,
    interpolate=FALSE,
    width=unit(1,"npc"),height=unit(1,"npc") )
}
