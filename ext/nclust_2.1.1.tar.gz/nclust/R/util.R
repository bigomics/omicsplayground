ccenter <- function(x) scale(x,scale=FALSE,center=TRUE)

rcenter <- function(x) x - apply(x,1,mean)
