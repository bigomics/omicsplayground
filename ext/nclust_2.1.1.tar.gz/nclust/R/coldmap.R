coldmap <- function(...) ng_hm1(...)
