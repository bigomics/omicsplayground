nnc_dense <- function(
   y, w = NULL, # data either separate weight or already 2xMxN (weight first)
   max_qlen = 32,  # NN queue length
   branchflip = 0, # 0: nearest-nephew, 1: tight-left, 2: tight-right
   standardize = TRUE,  # use correlation (if false, covariance)
   verbose = 1
   )
{
  if( is.null(w) && length(dim(y)) == 2 )
    {
    W <- 1
    M <- nrow(y)
    N <- ncol(y)

    x <- array(double(M*2*N), dim=c(M,2*N))
    x[,2:(N+1)] <- y
    }
  else if( !is.null(w) )
    {
    if( ! all( dim(y) == dim(w) ) ) stop("dim(y) != dim(w)")
    W <- 2
    M <- nrow(y)
    N <- ncol(y)

    x <- array( double(2*M*2*N),dim=c(2,M,2*N))
    x[1,,2:(N+1)] <- w
    x[2,,2:(N+1)] <- y
    }
  else if( length(dim(y)) == 3 )
    {
    W <- dim(y)[1]
    M <- dim(y)[2]
    N <- dim(y)[3]

    x <- array( double(2*M*2*N),dim=c(2,M,2*N))
    x[1:2,,2:(N+1)] <- y[1:2,,]
    }
  else
    stop("y is not an array with valid dimensions")

  if( max_qlen < 1 ) max_qlen <- 1

  r <- .C("nnc_dense",
    dim = as.integer( c(W, M, N) ),
    x = as.double(x),
    L = integer(2*N), R = integer(2*N), U = integer(2*N),
    S = double(2*N),
    order = integer(N),

    n = integer(2*N),
    leftmost = integer(2*N),
    level = integer(2*N),

    options = as.integer(
      c(max_qlen,branchflip,standardize,verbose)),
    retstat = integer(1),
    NAOK=FALSE
    )

  r$labels <- colnames(x)
  r$x <- NULL # no need to keep it, easy to regenerate

#  if( W == 1) dim(r$x) <- c(M, 2*N)
#  else dim(r$x) <- c(2,M,2*N)

  class(r) <- "nclust"
  return(r)
}
