tilemean <- function(
  x,              # numeric data matrix
  irow=NULL,      # row index (integer or characters)
  icol=NULL,      # col index (integer or characters)
  tilesize=c(1,1) # tile size
  )
{
  mx <- nrow(x)
  nx <- ncol(x)
  if( is.null(irow) ) irow <- 1:mx
  if( is.null(icol) ) icol <- 1:nx

  if( !is.numeric(tilesize) )
    stop("tilesize has to be numeric")
  tilesize <- as.integer(tilesize)  
  if( any((tilesize < c(1,1)) | (tilesize > c(mx,nx))) )
    stop("tilesize out of range.")

  if( is.character(irow) )
    {
    if( is.null(rownames(x)) )
      stop("`x` has no rownames to match `irow`")
    irow <- match( irow, rownames(x) )
    }
  else
    {
    irow <- ifelse( irow > mx | irow < 1, NA, irow )
    }
  irow <- c(irow, rep(NA, (tilesize[1] - length(irow)) %% tilesize[1]))

  if( is.character(icol) )
    {
    if( is.null(colnames(x)) )
      stop("`x` has no colnames to match `icol`")
    icol <- match( icol, colnames(x) )
    }
  else
    {
    icol <- ifelse( icol > nx | icol < 1, NA, icol )
    }
  icol <- c(icol, rep(NA, (tilesize[2] - length(icol)) %% tilesize[2]))
  
  my <- length(irow) / tilesize[1]
  ny <- length(icol) / tilesize[2]

  r <- .C("tilemean",
    as.integer(c(mx,nx,my,ny,tilesize)),
    as.integer(irow-1),
    as.integer(icol-1),
    as.double(x),
    y = double(my * ny),
    wrow = double(my),
    wcol = double(ny),
    NAOK=TRUE,
    PACKAGE="nclust")

  dim(r$y) <- c(my,ny)
  attr(r$y,"wrow") <- r$wrow
  attr(r$y,"wcol") <- r$wcol
  r$y
}

wrow <- function(x) attr(x,"wrow")

wcol <- function(x) attr(x,"wcol")
