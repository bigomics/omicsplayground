# dataset tiling
#
datatile <- function(tile,x,transpose=NULL)
{

}
