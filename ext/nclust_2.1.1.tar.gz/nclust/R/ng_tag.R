autocol <- function(k)
{
  if( k==1 ) return( c("black") )

  return( hsv( (0:(k-1))/k, s=.8,v=.8 ))
}


# color heatmaps of categorical labels

ng_tag <- function(
  z,  # tag matrix or data frame : row names should exist and match ref
  all,  # labels in the right order
  transpose=FALSE,  # column of z displayed as columns
  col.tag=NULL      # color scheme
  )
{
  if(transpose==FALSE)
    {
    m <- length(all)
    n <- ncol(z)
    }
  else
    {
    m <- ncol(z)
    n <- length(all)
    }

  print(col.tag)
  if( !is.list(col.tag) ) # already a color matrix
    {
    h <- z[ match(all,rownames(z)), ]
    }
  else
    {
    h <- sapply( 1:ncol(z), function(j)
      {
        u <- z[,j]
        if(!is.factor(u)) u <- as.factor(u)
        k <- nlevels(u)

        if( is.null(col.tag) || is.null(col.tag[[names(z)[j]]]) )
          colj <- autocol(k)
        else
          colj <- col.tag[[names(z)[j]]]
        
        print(levels(u))
        names(colj) <- as.character(levels(u))
        colj[ as.character(z[match(all,rownames(z)),j]) ]
      })
    }

  pushViewport(viewport())
  if(transpose==TRUE) h <- t(h)
  grid.raster( h, interpolate=FALSE, width=unit(1,"npc"),height=unit(1,"npc"))
}
