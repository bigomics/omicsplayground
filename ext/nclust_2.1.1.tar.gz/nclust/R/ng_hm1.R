
# convenience to navigate in a layout 
#
panel <- function(name, i,j)
{
  seekViewport(name)
  pushViewport(viewport(layout.pos.row=i,layout.pos.col=j))
}

# heatmap of one matrix

ng_hm1 <- function(
  x, w = NULL,
  rclust=NULL, cclust=NULL,
  clust=NULL,
  cwa=NULL,cwb=NULL,
  rwa=NULL,rwb=NULL,
  rlab=NULL,col.rlab=NULL,rlab.text=NULL,
  clab=NULL,col.clab=NULL,clab.text=NULL,
  rtag=NULL,col.rtag=NULL,
  ctag=NULL,col.ctag=NULL,
  rdend.space=5, cdend.space=4,
  rtag.space=0.5, ctag.space=0.5,
  rplot.space=0, cplot.space=0,
  rlab.space=3, clab.space=3,
  saturation = 2
  )
{
  # construct dendograms if not yet supplied
  if(!is.null(clust)) 
    { rclust <- clust$rclust; cclust <- clust$cclust }
  if(is.null(rclust))
    {
    if(is.null(w)) tw <- NULL
    else tw <- t(w)
    rclust <- nclust(t(x), w=tw, standardize=1 )
    }
  if(is.null(cclust))
    cclust <- nclust(x, w=w, standardize=1 )


  rmarg <- 1
  if(!is.null(rlab))
    {
    if(is.list(rlab) && is.list(rlab[[1]]))
      rmarg <- rmarg + rlab.space*length(rlab)
    else
      rmarg <- rmarg + rlab.space
    }

  tmarg <- 1
  if(!is.null(clab)) 
    {
    if(is.list(clab) && is.list(clab[[1]]))
      tmarg <- tmarg + clab.space*length(clab)
    else
      tmarg <- tmarg + clab.space
    }

  lmarg <- rdend.space
  bmarg <- cdend.space

  if(is.null(rtag))
    rtag.space <- 0

  if(is.null(ctag))
    ctag.space <- 0

  L <- grid.layout(
    ncol=5,
    widths=unit(c(lmarg,1,rtag.space,rplot.space,rmarg),
      c("cm","null","cm","cm","cm")),
    nrow=5,
    heights=unit(c(tmarg,cplot.space,ctag.space,1,bmarg),
      c("cm","cm","cm","null","cm"))
    )

  grid.newpage()
  pushViewport( viewport(layout=L, name="L"))

  # main coordinates: windows to cluster order
  m <- length(rclust$order)
  n <- length(cclust$order)
  if(is.null(rwa) || rwa < 1) rwa <- 1
  if(is.null(rwb) || rwb > m) rwb <- m
  if(is.null(cwa) || cwa < 1) cwa <- 1
  if(is.null(cwb) || cwb > n) cwb <- n

  # heatmap: with labels on the border
  panel("L",4,2)

  rbin = 1 + (rwb-rwa+1) %/% 500 
  cbin = 1 + (cwb-cwa+1) %/% 500
  ng_heatmap( x, rclust$order[rwa:rwb], cclust$order[cwa:cwb],
    rbin=rbin,cbin=cbin,
    saturation = saturation, cwa = cwa, rwb = rwb )
  xs <- ng_xscale()
  ys <- ng_yscale()

  if( !is.null(rtag) )
    {
    panel("L",4,3)
    ng_tag( rtag, rownames(x)[rclust$order[rwa:rwb]], col.tag=col.rtag )
    }

  if( !is.null(rlab) )
    {
    panel("L",4,5)
    pushViewport(viewport(yscale=ys))
    if(!is.null(rlab.text)) all.rlab <- rlab.text[rclust$order]
    else if(!is.null(rownames(x))) all.rlab <- rownames(x)[rclust$order]
    else all.rlab <- c()
    ng_label( all.rlab, rlab, col=col.rlab, horizontal=FALSE,
      wa=rwa,wb=rwb, base=unit(-1,"npc") )
    }
  
  if( !is.null(ctag) )
    {
    panel("L",3,2)
    ng_tag( ctag, transpose=TRUE,
      colnames(x)[cclust$order[cwa:cwb]], col.tag=col.ctag )
    }

  if( !is.null(clab) )
    {
    panel("L",1,2)
    pushViewport(viewport(xscale=xs))
    if(!is.null(clab.text)) all.clab <- clab.text[cclust$order]
    else if(!is.null(colnames(x))) all.clab <- colnames(x)[cclust$order]
    else all.clab <- c()
    ng_label( all.clab, space=clab.space, clab, col=col.clab, wa=cwa,wb=cwb, base=unit(-1,"npc") )
    }

  # row dendogram
  panel("L",4,1)
  pushViewport(plotViewport(c(0,4,0,1)))
  ng_dendrogram( rclust, horizontal=TRUE, wscale=ys,
   stemtype="relative",stemlength=0.05, nprune=rbin )
  grid.xaxis(main=FALSE)
  grid.yaxis()

  # column dendrogram
  panel("L",5,2)
  pushViewport(plotViewport(c(2,0,1,0)))
  ng_dendrogram( cclust, horizontal=FALSE, wscale=xs,
   stemtype="relative",stemlength=0.05,nprune=cbin)
  grid.yaxis()
  grid.xaxis()

  invisible( list(rclust=rclust,cclust=cclust) )
}
