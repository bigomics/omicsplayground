nclust <- function(...) nnc_dense(...)
