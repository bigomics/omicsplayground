hclust_merge_order <- function(h)
{
  o <- order(h$height)
  h$height <- h$height[o]
  h$merge <- h$merge[o,]
  h$merge <- apply( h$merge,2,
    function(u) ifelse(u < 0,u,order(o)[ifelse(u<0,NA,u)]))
  h
}


# convert nclust output to 'hclust' format
#
n2hclust <- function( clust )
{
  N <- clust$dim[3]
  h <- list()
  class(h) <- "hclust"
  h$order <- clust$order
  o <- rev(order(clust$S[ (N+2):(2*N)]))
  h$height <- 1-clust$S[ o + N + 1 ]
  h$merge <- array( integer((N-1)*2),c(N-1,2))

  vid2hid <- c( seq( -1, -N, -1), rep( 0, N-1) )
  vid2hid[ N + o ] <- 1:(N-1)
  h$merge[,1] <- vid2hid[ clust$L[(N+2):(2*N)]][o]
  h$merge[,2] <- vid2hid[ clust$R[(N+2):(2*N)]][o]

  hclust_merge_order(h)
}
