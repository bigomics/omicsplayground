extern "C" {
    SEXP gpuMatMult(SEXP a, SEXP b);
}
