# create the union of all column labels.
# make a matrix of indices that map the unique labels (row names)
# to indices in each dataset (each column of this matrix)
#
union.col <- function(...)
{
  d <- list(...)
  colnames.uni <- unique( sort(unlist(sapply(d, function(u) colnames(u))) ) )
  col.idx <- sapply( d, function(u) match(colnames.uni,colnames(u)))
  col.idx <- ifelse( is.na(col.idx), 0, col.idx )
  rownames(col.idx) <- colnames.uni
  col.idx
}

#
# subset an hclust object 'h', keeping the selected nodes specified
# by indicator vector 'd', and eliminating
# the rest, while preserving the tree topology and height.
#
dendropart <- function(h,d)
{
  if(length(d) != length(h$height)+1 ) stop("d: wrong length")
  d <- as.integer( ifelse(is.na(d),0,d) )
  m <- sum(d)
  r <- .C("R_dendropart",as.integer(length(h$order)),
    as.integer(h$merge),
    # as.double(h$height),
    as.integer(d),as.integer(m),
    merge=integer(2*(m-1)),
    supbranch=integer(m-1),  # old branch indices, one offset
    DUP=FALSE)
  e <- rep(0,length(d))
  e[d == 1] <- 1:m 
  s <- list(
    merge=sapply(r$merge,function(x)ifelse(x < 0, -e[-x],x)),
    height=h$height[r$supbranch],
    sup.branch =r$supbranch,
    sup.leaf = (1:length(d))[d == 1],
    order=e[h$order[d[h$order]==1]],
    labels=h$labels[d==1])
  dim(s$merge) <- c(m-1,2)
  class(s) <- "hclust"
  s
}

# nclust for multiple dense matrix input
#
#
nclust.mmat <- function(...,
  distance="nzcor.rema",
  link="ave",
  branchflip="nnephew",
  pwcorr = FALSE
  )
{
  d <- list(...)
  K <- length(d)

  nrow.d <- sapply(d,function(u)nrow(u))
  ncol.d <- sapply(d,function(u)ncol(u))
  
  if(K > 1 )
    unicol <- union.col(...)
  else
    {
    nc <- ncol(d[[1]])
    unicol <- array( 1:nc, dim=c(nc,1) )
    rownames(unicol) <- colnames(d[[1]])
    if( distance == "nzcor.rema" ) { distance <- "nzcor.fema" }
    }

  nu <- nrow(unicol)
  if( nu <= 2 )
    stop("nclust can not handle fewer than three items")

  col.idx <- integer(nrow(unicol) * ncol(unicol))
  dim(col.idx) <- c(nrow(unicol),ncol(unicol))
  
  ndata <- ncol.d * nrow.d
  bdata <- cumsum(ndata)
  adata <- c(0,bdata[1:(K-1)])+1
  data <- double( sum(ndata) )

  for(k in 1:K)
    {
    ik <- unicol[,k]
    data[adata[k]:bdata[k]] <- c(d[[k]][,ik])
    o <- integer(0)
    o[ik[ik!=0]] <- 1:ncol.d[k]
    nik <- o[ ifelse(ik == 0,NA,ik) ]
    col.idx[,k] <- ifelse(is.na(nik),0,nik)
    }

  disscode <- pmatch(distance,c("nzcor.rema","nzcor.fema")) - 1
  if( is.na(disscode) )
    stop(paste("distance '",distance,"' not implemented",sep=""))

  linkcode <- pmatch(link,c("average","mcquitty","ward","single","complete","allpair")) - 1
  if( is.na(linkcode) )
    stop(paste("link '",link,"' not implemented",sep=""))

  bflipcode <- pmatch(branchflip,c("nnephew","tightleft")) - 1
  if( is.na(bflipcode) )
    stop(paste("branchflip '",branchflip,"' not implemented",sep=""))

  npw <- if(pwcorr == TRUE ) nu*nu else 0

  r <- .C("R_mmat_nclust", as.integer(K),
    as.integer(nrow.d), as.integer(ncol.d),
    as.integer(nu), as.integer(col.idx),
    as.double(data),
    
    as.integer(disscode),
    as.integer(linkcode), 
    as.integer(bflipcode),

    s2 = double(nu), df = integer(nu),
    merge = integer(2*(nu-1)),
    linkscore = double(nu-1),
    order = integer(nu),
    leaf.level = integer(nu),
    branch.level = integer(nu-1),
    n.leaf = integer(nu-1),
    sum.level = integer(nu-1),
    sumsq.level = double(nu-1),
    bounds = integer(2*(nu-1)),
    n.leaf.parent = integer(nu-1),

    as.integer(pwcorr),
    pwdist = double(npw),

    NAOK = TRUE,DUP=FALSE
    )

  u <- list(
    merge = r$merge,
    order = r$order,
    labels = rownames(unicol),
    linkscore = r$linkscore,
    leaf.level = r$leaf.level, 
    leaf.corr = r$leaf.level,
    branch.level = r$branch.level,
    branch.corr = -tanh(r$linkscore),
    n.leaf = r$n.leaf,
    sum.level = r$sum.level,
    sumsq.level = r$sumsq.level,
    n.leaf.parent = r$n.leaf.parent,
    bounds = r$bounds,
    N = sum(nrow.d),
    s2 = r$s2, df = r$df, unicol = unicol
    )
  u$height <- -log2(u$branch.level+1)
  u$height <- u$height - min(u$height)
  dim(u$merge) <- c(length(u$merge)/2,2)
  dim(u$bounds) <- dim(u$merge)

  if( pwcorr == TRUE )
    {
    u$pwcorr <- -tanh(r$pwdist)
    dim(u$pwcorr) <- c(nu,nu)
    for(i in 1:nu) u$pwcorr[i,i] = 1
    colnames(u$pwcorr) <- rownames(u$pwcorr) <- u$labels
    }


  v <- double(length(u$leaf.corr))
  for(i in 1:length(u$height))
    {
    if(u$merge[i,1] < 0) v[-u$merge[i,1]] = u$branch.corr[i]
    if(u$merge[i,2] < 0) v[-u$merge[i,2]] = u$branch.corr[i]
    }
  u$leaf.corr <- v[u$order]

  class(u) <- "hclust"
  u
}

# row and column clustering
nclust2 <- function(..., mostvarcol=0.5,cclust = NULL,labels=NULL,center=TRUE,
  distance="nzcor.rema", link="ave", branchflip = "nnephew", rpwcorr=TRUE,
  cpwcorr=FALSE)
{
  d <- list(...)
  K <- length(d)
  if( is.null(labels))
    labels <- 1:K
  if( length(labels) != K ) stop("length of labels doesn't match # datasets")


  ## column clustering
  if(is.null(cclust))
    v <- nclust.mmat(...,distance=distance,link=link,branchflip=branchflip,
      pwcorr=cpwcorr)
  else
    v <- cclust
  nu <- nrow(v$unicol)
  n.vs <- as.integer( nu * mostvarcol )
  name.vs <- rownames(v$unicol)[order(v$s2,decreasing=TRUE)[1:n.vs]]
  data <- do.call("cbind",lapply( d,
    function(x)t( scale(x[,match(name.vs,colnames(x))],
      center=center,scale=ifelse(center==TRUE,FALSE,TRUE) ))))
  rownames(data) <- name.vs

  ## row clustering
  # prepend dataset labels
  colnames(data) <- as.vector(unlist(mapply(
    function(u,v){paste(u,rownames(v),sep=":")},labels,d)))
  w <- nclust.mmat(data,distance=distance,link=link,
    branchflip=branchflip, pwcorr = rpwcorr )

  # make per dataset ordering
  nrow.d <- sapply(d,function(u)nrow(u))
  b.row <- cumsum(nrow.d)
  a.row <- c(0,b.row[-K])+1

  w$subclust <- mapply(SIMPLIFY=FALSE,
    function(a,b) { s <- rep(0,ncol(data)); s[a:b] <- 1; dendropart( w, s ) },
    a.row, b.row )

  list(cclust = v, rclust = w )
}


