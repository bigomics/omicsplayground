

# pairwise (dis)similarity heatmaps

pwmap <- function( C, dlab=NULL, col=rb.colors, saturation=.666,
  gutter = NULL, proportional = TRUE, rgap = 0.5,
  rdw = 3, cdw = 3, stratify = TRUE, hang=.05, ticks = NULL )
{
  par0 <- par( no.readonly=TRUE )
  on.exit( par(par0) )

  if( is.null(C$subclust) ) stratify <- FALSE

  if( is.null(C$pwcorr) )
    stop("pairwise correlation matrix not present. rerun nclust2 with rpwcorr=TRUE")

  K <- if( stratify ) length(C$subclust) else 1

  L <- rbind(
          rep(0,K+2),
          cbind(rep(0,K),array( 1:(K*K),dim=c(K,K)),rep(0,K)),
          rep(0,K+2))

  L[K+2,1 + (1:K)] <- (K*K)+(1:K)
  L[1+(1:K),1] <- K*(K+1) + (1:K)

  if( K > 1 )
    {
    mn <- mean(sapply(C$subclust,function(i)length(i$labels)))
    if(is.null(gutter)) gutter <- 0.05*mn
    if( proportional )
      w <- sapply(C$subclust,function(i)length(i$labels)) + gutter
    else
      w <- rep( mean(sapply(C$subclust,function(i)length(i$labels))), K )+gutter
    }
  else
    {
    w <- 1
    if(is.null(gutter)) gutter <- 0
    }

  if(proportional == FALSE )
    gutter <- 0
  else
    rgap <- 0

  layout( L, widths=c(lcm(rdw),w,lcm(2)),
    heights=c(lcm(2),w,lcm(cdw)) )

  sx <- sd( c(C$pwcorr) )
  
  for(i in 1:K)
    {
    Si <- if( stratify ) C$subclust[[i]] else C
    li <- Si$labels[ Si$order ]
    for(j in 1:K )
      {
      Sj <- if( stratify ) C$subclust[[j]] else C
      
      par(mar = c(rgap,rgap,rgap,rgap))

      lj <- Sj$labels[ Sj$order ]

      rres <- length(lj) %/% 500 + 1
      cres <- length(li) %/% 500 + 1
      dx <- t( downsample( C$pwcorr[ lj, rev(li) ], cres, rres,
        rcenter=FALSE, ccenter = FALSE ) )

      image( tanh( saturation*(dx)/sx ),
        zlim=c(-1,1), col=col,
        x = seq( 1, length(li),rres ), xlim=c(1,length(li)+gutter),
        y = seq( 1, length(lj),cres ), ylim=c(1,length(lj)+gutter),
        axes=FALSE
        )
      if( i==1 )
        {
        if( is.null(ticks) ) ti <- pretty(c(1,length(lj)),n=5)
        else ti <- seq(ticks,length(lj),ticks)
        ti <- ti[ ti > 0 & ti < length(lj) ]
        axis(2,at=ti,cex.axis=.8)
        }
      if( j==K )
        {
        if( is.null(ticks) ) ti <- pretty(c(1,length(li)),n=5)
        else ti <- seq(ticks,length(li),ticks)
        ti <- ti[ ti > 0 & ti < length(li) ]
        axis(1, at=ti, cex.axis=.8)
        }
      }
    }

  rdend <- dendrolines(C,hang=hang,height=-C$branch.level)
  rdend.range <- range(-rdend$y)

  for(i in 1:K)
    {
    subclust <- if(stratify) C$subclust[[i]] else C
    u <- dendrolines( subclust,
      hang=hang, 
      height= -if(stratify)
                C$branch.level[subclust$sup.branch]
               else
                C$branch.level
      )
    par(mar=c(2,rgap,2,rgap))
    plot( length(subclust$labels) - u$x +1, -u$y, type="l",axes=FALSE,ann=FALSE, xaxs="i",
      ylim=rdend.range, xlim=c(0.5,length(subclust$labels)+0.5+gutter) )
    if(!is.null(dlab))
      {
      lab <- if(stratify) dlab[i] else do.call(paste,as.list(c(dlab,sep=":")))
      mtext( lab, side=1,line=.5,at=length(subclust$labels)/2,cex=.8)
      }
    }

  for(i in 1:K)
    {
    subclust <- if(stratify) C$subclust[[i]] else C
    u <- dendrolines( subclust,
      hang=hang, height= -if(stratify)
        C$branch.level[subclust$sup.branch] else C$branch.level )
    par(mar=c(rgap,2,rgap,2))
    plot( -u$y, u$x, type="l",axes=FALSE,ann=FALSE, yaxs="i",
      xlim=rdend.range, ylim=c(0.5,length(subclust$labels)+0.5+gutter) )
    if(!is.null(dlab))
      {
      lab <- if(stratify) dlab[i] else do.call(paste,as.list(c(dlab,sep=":")))
      mtext( lab, side=2,line=.5,at=length(subclust$labels)/2,cex=.8)
      }
    }
}

