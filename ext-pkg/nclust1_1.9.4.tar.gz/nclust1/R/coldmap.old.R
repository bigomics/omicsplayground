
coldmap.old <- function( x,
  clust = NULL,
  cclust = NULL,
  rclust = NULL,
  ccenter = TRUE,
  rcenter = FALSE,
  downsampling = NULL,
  col = rg.colors,
  saturation = .666, 
  clab = NULL, 
  labspace=0.01,
  labcol = NULL,
  zc = NULL,
  zw = NULL
  ){
  m <- dim(x)[1]
  n <- dim(x)[2]

  # use supplied clustering
  if( class(clust) == "list"
    && class(clust$cclust) == "hclust"
    && class(clust$rclust) == "hclust" )
    { cclust <- clust$cclust; rclust <- clust$rclust; }

  # or compute when not available
  if( class(cclust) != "hclust")
    cclust <- nclust(x,impute=TRUE)
  if( class(rclust) != "hclust")
    rclust <- nclust(t(mostvar(x,n %/% 2)),center="both")

  if( length(cclust$order) != n || length(rclust$order) != m )
    stop("clust objects size doesn't match that of the matrix")

  # ordered labels
  ordlab <- cclust$labels[cclust$order]

  # determine the window
  if(is.null(zc))
    { wa <- 1; wb <- n; zw <- n }
  else
    {
    if(is.character(zc))
      zc <- match(zc, ordlab)
    if(is.na(zc) || is.null(zw) )
      { wa <- 1; wb <- n; zw <- n }
    else
      {
      wa <- max( 1, zc - zw %/% 2 )
      wb <- min( n, zc + zw %/% 2 )
      }
    }

  ## start drawing
  default.par <- par(no.readonly=TRUE)

  layout( array(c(0,2,0,1,3,0,0,4,0),dim=c(3,3)),
    widths=c(lcm(4),1,lcm(2.5)),
    heights=c(lcm(3),1,lcm(1))) 

  # top dendrogram
  v <- dendrolines(rclust)
  par(mar=c(2,0,0,0))
  plot(v$x,v$y,type="l",axes=FALSE,ann=FALSE, xlim=c(.5,m+.5), xaxs = "i")

  # left dendrogram
  u <- dendrolines(cclust,hang=0.025)
  par(mar=c(0,0,0,2))
  plot(-u$y,u$x,type="l",axes=FALSE,ann=FALSE, yaxs="i", ylim=c(wa,wb))

  # heatmap
  par(mar=c(0,0,0,0))

  if( is.null(downsampling) )
    { rds <- m %/% 500 + 1; cds <- zw %/% 500 + 1; }
  else
    { rds <- max(1,downsampling[1]); cds <- max(1,downsampling[2]) }
  
  dx <- downsample( x,
    rds, cds, ridx = rclust$order, cidx = cclust$order[wa:wb],
    rcenter = rcenter, ccenter = ccenter )

  image( tanh(saturation*(dx-attr(dx,"mean"))/attr(dx,"sd")),
    col=col,zlim=c(-1,1),
    y=seq(wa,wb,cds), ylab="",
    x=seq(1,m,rds), xlab="",axes=FALSE)
  axis(2)
  axis(3)

  # column labels
  if( !missing(clab) )
    {
    if(is.character(clab))
      i <- unique(as.vector(na.omit(match( clab, ordlab ))))
    else
      i <- as.integer(clab)

    i <- i[i >= wa & i <= wb]
    plot.new()
    plot.window(c(0,1),c(wa-.5,wb+.5),yaxs="i")
    space <- labspace*zw
    if(length(i) > 0)
      {
      j <- labelpack(i, space = space,
        minx = wa - 0.5 + .5*space, maxx = wb + .5 -.5*space )
      text( rep(0.205, length(i)), j, ordlab[i],
        pos = 4, col = labcol )

      # bent ticks
      apply(rbind(i,j),2,
        function(u)lines(c(0,.05,.1,.2),c(u[1],u[1],u[2],u[2])))
      }
    }
  invisible(list(rclust = rclust,cclust = cclust))
  }
