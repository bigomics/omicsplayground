require(grDevices)

downsample <- function(x, rres,cres,
  ridx = 1:nrow(x), cidx = 1:ncol(x), rcenter=TRUE, ccenter=TRUE)
{
  m <- length(ridx); n <- length(cidx);
  my <- (m+rres-1) %/% rres; ny <- (n+cres-1) %/% cres; 
  r <- .C("R_downsample",
    as.integer(nrow(x)),as.integer(ncol(x)),as.double(x),
    as.integer(rres),as.integer(cres),
    as.integer(m), as.integer(n),
    as.integer(ridx-1), as.integer(cidx-1),
    as.integer( rcenter + 2*ccenter ),
    y = double(my*ny), meany = double(1), sdy = double(1),
    NAOK=TRUE,DUP=FALSE);
  dim(r$y)=c(my,ny);
  attr(r$y,"mean") <- r$meany
  attr(r$y,"sd") <- r$sdy
  r$y
}

labelpack <- function(x,space = NULL, spacefrac = 0.05,
  minx = min(x), maxx = max(x), maxiter = 50){
  n <- length(x)
  o <- order(x)

  if(missing(space))
    space <- spacefrac*(maxx-minx)
    
  r <- .C("R_labelpack",as.integer(n),as.double(x[o]),
    as.double(space),as.double(minx),as.double(maxx),
    as.integer(maxiter),y = double(n))
  r$y[o] <- r$y
  r$y }

# red-black-green gradient
rg.colors <- c(rgb(0,seq(1,.1,-.1),0), rgb(0,0,0), rgb(seq(.1,1,.1),0,0) ) 

# red-white-blue gradient
rb.colors <- c(hsv(0.66,seq(1,.1,-.1),1), rgb(1,1,1), hsv(0,seq(.1,1,.1),1) ) 

# black-and-white
bw.colors <- gray(seq(21,0,-1)/21)

coldmap <- function(..., clust=NULL,
  dlab=NULL,
  clab = NULL,
	alt.colnames=NULL,  # alternate column names
  clab.height = 2,
  col.clab=1,
  cex.clab=.8,
  rlab = NULL,
  rlab.width = 1.5,

  rannot = NULL,
  rannot.width = 1.5,

  col=rb.colors,
  saturation=.666,
  downsampling = NULL,
  rcenter = FALSE,
  ccenter = TRUE,

  wa=NULL, wb=NULL,
  rw=1,rwa=NULL, rwb=NULL,
  chang = 0.0,
  rhang = 0.05,
  gutter=NULL, proportional = TRUE,
  rpwcorr=TRUE,
  cpwcorr=FALSE,
  rdw = NULL, cdw =NULL,
  rgap = 0.5,
  rticks = NULL, cticks = NULL,
	rorder = NULL,
  corder = NULL,

  cplot = NULL, cplot.band=c(0), cplot.height = 2,cplot.gutter=0.4, cplot.panel=nclust1:::cplot.points,
  rclist = NULL
  )
{
  d <- list(...)
  K <- length(d)
  if(is.null(clust))
    clust <- nclust2(...,rpwcorr=rpwcorr,cpwcorr=cpwcorr)

  if(missing(cplot)) cplot.height = 0.1
  else cplot.height <- cplot.height * ( if(is.matrix(cplot)) dim(cplot)[1] else 1 )
  if(missing(clab)) clab.height=0.5
  if(missing(rlab)) rlab.width=0.1
  if(missing(rannot)) rannot.width=0.1
  if(!is.null(rwa) || !is.null(rwb)) proportional=FALSE

  par0 <- par(no.readonly=TRUE)
  on.exit(par(par0))

  # make per dataset ordering
  nrow.d <- sapply(d,function(u)nrow(u))
  b.row <- cumsum(nrow.d)
  a.row <- c(0,b.row[-K])+1
  N <- sum(nrow.d)

	if(is.null(cdw) )
		{
		if( !is.null(corder) ) cdw <- 3
		else cdw <- 3
		}
	if(is.null(rdw) )
		{
		if( !is.null(rorder) ) rdw <- 3
		else rdw <- 3
		}

  if( K > 1 )
    {
    if(is.null(gutter)) gutter <- 0.05 * mean(nrow.d) 
    if( proportional )
      w <- nrow.d + gutter
    else
      w <- rep(mean(nrow.d),K) + gutter
    }
  else
    {
    w <- 1
    if( is.null(gutter)) gutter <- 0
    }
  if( proportional == FALSE )
    gutter <- 0
  else
    rgap <- 0

  L <- array(
    c(0,seq(1,2*K,2),0,2*K+2,seq(2,2*K,2),2*K+1,rep(0,K+2)),
    dim=c(K+2,3))

  # for rannot
  for(k in 1:K)
    L[1+k,3] = 2*K+2+k
  L[1,3] <- 2*K+2+K+1

  # for rlab
  L <- cbind( L, rep(0,K+2) )
  L[2:(K+1),4] <- (L[1,3]+1):(L[1,3]+K)

  # for cplot
  L <- rbind( c(0,L[1,3]+K+1,0,0), L )

  layout(
    L,
    widths=c( lcm(rdw), 10, lcm(rannot.width), lcm(rlab.width) ),
    heights=c(lcm(cplot.height),lcm(clab.height),w,lcm(cdw))  )

  # draw individual heatmap

  cc <- clust$cclust
  if(is.null(corder))
    nu <- nrow(cc$unicol)
  else
    {
    if( !is.character(corder) )
      stop("corder has to be vector of characters.")
    nu <- length(corder)
    }

	if(!is.null(rorder))
		{
		if( K == 1 )
			{
			if( is.vector(rorder) ) 
				{
			  if( !is.character(rorder) )
					stop("rorder has to be a character vector");
				rorder <- list( rorder )
				}
			else if( is.list(rorder) )
				{
			  if( length(rorder) != 1 )
					stop("rorder length not equal to one.")
				if(!is.character(rorder[[1]]) )
					stop("rorder first element is not a character vector")
				}
			else
				stop("rorder has to be (a list of) one character vector");
			}
		else
			{
			if( !is.list(rorder) )
				stop("rorder has to be a list")
			if( length(rorder) != K )
				stop("length of 'rorder' not equal the number of datasets")
			}
		}

  if( is.null(wa) || wa < 1 )
    wa <- 1
  if( is.null(wb) || wb > nu )
    wb <- nu

  if( is.null(downsampling[2]) )
    cres <- (wb-wa+1) %/% 400 + 1
  else
    cres <- downsampling[2]

  # get the total range of row dendrogram by constructing the total
  if( is.null(rclist) )
    {
    rc <- clust$rclust 
    rdend <- dendrolines(rc, hang=rhang, height=-rc$branch.level)
    rdend.range <- range(-rdend$y)
    }
  else
    {
    if(length(rclist) != K ) stop("rclist length doesn't match number of datasets")
    rdend.range <- c(+Inf,-Inf)
    for(k in 1:K)
      {
      r <- rclist[[k]]
      rdend <- dendrolines(r,hang=-rhang,height=-r$height)
      rr <- range(rdend$y)
      if(rdend.range[1] > rr[1] ) rdend.range[1] <- rr[1]
      if(rdend.range[2] < rr[2] ) rdend.range[2] <- rr[2]
      }
    }

  for(k in 1:K) 
    {
    rwak <- 1
    rwbk <- nrow.d[k]
    if( k == rw )
      {
      if( !is.null(rwa) )
        rwak <- max(rwa,rwak)
      if( !is.null(rwb) )
        rwbk <- min(rwb,rwbk)
      }

    # row dendrograms
    
		if( is.null(rorder) )
			{
			if( is.null(rclist) )
				{
				subclust <- rc$subclust[[k]]
				u <- dendrolines(subclust,hang=rhang,
							height=-rc$branch.level[subclust$sup.branch])
				par(mar=c(rgap,2,rgap,2))
				plot(-u$y,u$x,type="l",axes=FALSE,ann=FALSE,
					ylim=c(rwak-0.5,rwbk+0.5+gutter), xlim=rdend.range, yaxs="i" )
				}
			else
				{
				subclust <- rclist[[k]]
				u <- dendrolines(subclust,height=subclust$height,hang=rhang)
				par(mar=c(rgap,2,rgap,2))
				plot(-u$y,u$x,type="l",axes=FALSE,ann=FALSE,
					ylim=c(rwak-0.5,rwbk+0.5+gutter), xlim=rdend.range, yaxs="i" )
				}
			}
		else
			{
			subclust <- rc$subclust[[k]]
			plot.new()
			}

    # dataset label
    mtext(dlab[k],side=2,line=1,at=(rwbk+rwak)/2,cex=.8)
    
    # heatmap
    par(mar=c(rgap,1,rgap,1))
    ik <- cc$unicol[,k]
    ik <- ifelse(ik == 0, NA, ik)

    if( is.null( downsampling[1] ) )
      rres <- (rwbk-rwak+1) %/% 300 + 1
    else
      rres <- downsampling[1]
    
    if( is.null(corder) )
      subcols <- cc$order[wa:wb] 
    else
      subcols <- match( corder, cc$labels )[wa:wb]

		if( is.null(rorder) )
			subrows <- subclust$order[rwak:rwbk]
		else
			subrows <- match( gsub("^",paste0(k,":"),rorder[[k]]),
											 subclust$labels )[rwak:rwbk]

    dx <- t(downsample(
      d[[k]][ subrows, ik[ subcols ] ],
      rres, cres, 
      rcenter=rcenter,ccenter=ccenter ))
    
    image( tanh( saturation*(dx)/attr(dx,"sd")),
      zlim=c(-1,1),col=col,
      y=seq(rwak,rwbk,rres),
      ylab="",
      ylim=c(rwak-0.5,rwbk+0.5+gutter),
      x=seq(wa,wb,cres),
      xlab="",
      useRaster=TRUE,
      axes=FALSE)

    ### heatmap axis
    
    # row tick marks
		if(is.null(rorder)) o <- subclust$order
		else o <- rorder[[k]]

    rtlab <- TRUE
    if( is.numeric(rticks) )
      rti <- seq(rticks[1],rwbk,rticks[1])
    else if( !is.null(rticks) && rticks == "l" ) # labels
      {
      rti <- rwak:rwbk
      rtlab <- subclust$labels[o][rwak:rwbk]
      rtlab <- sub("^[0-9][0-9]*:","",rtlab)  # remove prefix
      }
    else
      rti <- pretty(c(rwak,rwbk,n=5))

    if( !is.character(rtlab) )
      {
      rti <- rti[ rti > rwak & rti < rwbk ]
      axis(2, at=rti, cex.axis=.8)
      }
    else
      {
      axis(2, at=rti, labels=rtlab,las=1, cex.axis=.8)
      }

    # column tick marks
    if(k == K)
      {
      if(is.null(cticks)) ct <- pretty(c(wa,wb),n=10)
      else ct <- seq(cticks,nu,cticks)
      ct <- ct[ ct > 1 & ct < nu ]
      axis(1, at=ct, cex.axis=.8)
      }
    }

  # column dendrogram
  h <- cc$branch.corr
  hcut <- cres
  for(i in length(h):1)
    {
    if(cc$merge[i,1] > 0 && cc$n.leaf[cc$merge[i,1]] <= hcut)
      h[cc$merge[i,1]] <- h[i]
    if(cc$merge[i,2] > 0 && cc$n.leaf[cc$merge[i,2]] <= hcut )
      h[cc$merge[i,2]] <- h[i]
    }
  u <- dendrolines(cc, hang=chang, height=-h)
  par(mar=c(1,1,2,1))
  if(is.null(corder))
    {
    plot(u$x,-u$y,type="l",axes=FALSE,ann=FALSE,xlim=c(wa-.5,wb+.5),
      xaxs = "i" )
    axis(2,at=c(0,.2,.4,.6,.8,1),labels=c("0",".2",".4",".6",".8","1"),cex.axis=.8)
    }
  else
    {
    plot.new()   # do nothing
    }

  # column labels
  par(mar=c(0,1,0,1))
  plot.new()
  plot.window(c(wa-.5,wb+.5),c(0,1),xaxs="i",xpd=NA)
  if( !missing(clab) )
    {
		if(is.null(alt.colnames))
			thelabels <- cc$labels
		else
			thelabels <- alt.colnames

    if(is.null(corder))
      ordlab <- thelabels[cc$order]
    else
      ordlab <- thelabels[match(corder,thelabels)]

    if(is.character(clab))
    #  i <- unique(as.vector(na.omit(match( clab, ordlab ))))
			i <- unlist(sapply(clab,function(s) grep(paste0("^",s,"$"),ordlab)))
    else
      i <- as.integer(clab)

    i <- i[ i >= wa & i <= wb ]

    if(length(i) > 0)
      {
      recordGraphics(
        {
        s <- 0.6*par("cin")[2] / par("pin")[1] * (wb-wa+1) * cex.clab
        j <- nclust1:::labelpack(i, space = s,
          minx = wa , maxx = wb    )
        text( x=j, y=rep(0.17, length(i)), cex = cex.clab,
          labels=lab, col=col.clab, adj=c(0,.5), srt=90,xpd=NA )

        # bent ticks
        apply(rbind(i,j,col.clab),2,
          function(u)lines( c(u[1],u[1],u[2],u[2]), c(0,.05,.1,.15),col=u[3] ))
        },
        list(i=i,cex.clab=cex.clab,lab=ordlab[i],
        col.clab=col.clab,wa=wa,wb=wb),
        getNamespace("graphics")
        )
      }
    }

  # additional matrix
  if( !is.null(rannot) )
    {
    for(k in 1:K)
      {
      rwak <- 1
      rwbk <- nrow.d[k]
      if( k == rw )
        {
        if( !is.null(rwa) )
          rwak <- max(rwa,rwak)
        if( !is.null(rwb) )
          rwbk <- min(rwb,rwbk)
        }
      if( is.null(rclist) || !is.null(rorder) )
        subclust <- clust$rclust$subclust[[k]]
      else
        subclust <- rclist[[k]]

      if(!is.null(rannot) && !is.null(rannot[[k]]))
        {
        cpos <- unique(sort(c(rannot[[k]])))
        cid <- 1:length(cpos)
        names(cid) <- cpos

				if(is.null(rorder)) subrows <- subclust$order
				else subrows <- rorder[[k]]
        
				z <- apply( t(rannot[[k]][subrows,]), c(1,2), function(u)cid[u] )
        par(mar=c(rgap,1,rgap,1))
        image(z=z, col=cpos,xaxs="i",yaxs="i",axes=F,
          y=seq(1,nrow.d[k]),
          ylim=c(rwak-0.5,rwbk+0.5+gutter))

        }
      }
    if( !is.null(colnames(rannot[[1]])) )
      {
      M <- length(colnames(rannot[[1]]))
      par(mar=c(0,1,0,1))
      plot.new()
      plot.window(c(.5,M+.5),c(0,1),xaxs="i")
      text( x=1:M, y=rep(0,M), labels=colnames(rannot[[1]]),
        cex = cex.clab, adj=c(0,.5), srt=90,xpd=NA)
      }
    else
      { par(mar=c(0,0,0,0)); plot.new(); }
    }
  else # draw nothing
    {
    for(k in 1:K)
      {
      par(mar=c(0,0,0,0));plot.new();
      }
    par(mar=c(0,0,0,0));plot.new();
    }

  # row labels
  for(k in 1:K)
    {
    rwak <- 1
    rwbk <- nrow.d[k]
    if( k == rw )
      {
      if( !is.null(rwa) )
        rwak <- max(rwa,rwak)
      if( !is.null(rwb) )
        rwbk <- min(rwb,rwbk)
      }
    par(mar=c(rgap,0,rgap,0))
    plot.new()
    plot.window( c(0,1), c(rwak-.5,rwbk+.5+gutter), yaxs="i")

    if( is.null(rclist) )
      subclust <- clust$rclust$subclust[[k]]
    else
      subclust <- rclist[[k]]
    
		if(is.null(rorder)) subrows <- subclust$order
		else subrows <- rorder[[k]]

    if( k <= length(rlab) && !is.null(rlab[[k]]) )
      {
      rl <- rlab[[k]]
      ordlab <-subclust$labels[subrows]
      if(is.character(rl))
        i <- unique( as.vector(na.omit(
          match(paste(as.character(k),rl,sep=":"),ordlab))))
      else
        i <- as.integer(rl)

      i <- i[ i >= rwak & i <= rwbk ]

      if( length(i) > 0 )
        {
        recordGraphics(
          {
          s <- 0.6*par("cin")[2] / par("pin")[2] * (rwbk-rwak+1) * cex.clab
          j <- nclust1:::labelpack(i, space = s,
            minx = rwak - 0.5 - .5*s , maxx = rwbk + .5 +.5*s  )
          text( y=j, x=rep(0.17, length(i)), cex = cex.clab,
            labels=lab, col=col.lab, adj=c(0,.5), srt=0,xpd=NA )

          # bent ticks
          apply(rbind(i,j),2,
            function(u)lines( c(0,.05,.1,.15),c(u[1],u[1],u[2],u[2]) ))
          },
          list(i=i,cex.clab=cex.clab,
            lab=sub("^[0-9][0-9]*:","",ordlab[i]),
          col.lab=col.clab,rwak=rwak,rwbk=rwbk),
          getNamespace("graphics")
          )
        }
      }
    }

  # cplot
  if( !is.null(cplot) )
    {
    par(mar=c(1,1,1,1))
    nclust1:::mplot( cplot, xlim=c(wa-.5,wb+.5), band=cplot.band,
      cex.axis=.8, gutter=cplot.gutter, panel=match.fun(cplot.panel))
    }
  else
    {
    par(mar=c(0,0,0,0))
    plot.new()
    }

  invisible(clust)
}
