goodbranch <- function(C, alpha = 0.9, epsilon = 1.5 )
{
  nsib <- C$n.leaf.parent - C$n.leaf
  o <- exp( log(C$n.leaf/nsib) + 2*sqrt(1/C$n.leaf + 1/nsib) )
  s <- sqrt( (C$sumsq.level - 2*(C$branch.level+log2(C$n.leaf))*C$sum.level
    + C$n.leaf * (C$branch.level+log2(C$n.leaf))^2 )/C$n.leaf )
  (1:length(C$n.leaf))[
  (s >  epsilon)
  &
  (o/(o+1)) < alpha
  ]
}
goodbranch.old <- function(C, alpha = 0.9, epsilon = 1 )
{
  nsib <- C$n.leaf.parent - C$n.leaf
  o <- exp( log(C$n.leaf/nsib) + 2*sqrt(1/C$n.leaf + 1/nsib) )

  (1:length(C$n.leaf))[
  (C$sum.level/C$n.leaf - C$branch.level > log2(C$n.leaf) + epsilon)
  &
  (o/(o+1)) < alpha
  ]
}
