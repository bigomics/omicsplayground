multires <- function(y,K=NULL)
{
  if(is.null(K)) K = ceiling(log2(length(y)))
  r <- .C("multires", as.integer(length(y)), as.double(y),
    as.integer(K),z=double(length(y)*K))
  dim(r$z) <- c(length(y),K)
  r$z
}

extremepoints <- function(y,cutoff=0)
{
  n <- length(y)
  r <- .C("extreme_points",as.integer(n),as.double(y),
    as.double(cutoff),np = integer(1), 
    pos = integer(n),double(0))
  m <- r$np
  list(pos = r$pos[1:m], val = y[r$pos[1:m]], np = r$np)
}


mrplot <- function( x, xlim=NULL, ylim = NULL, input=0 )
{
  par0 <- par(no.readonly = TRUE)
  on.exit( par(par0) )

  n <- dim(x)[1]
  K <- dim(x)[2]
  layout( array( 1:K,dim=c(K,1) ) )
  for(i in 1:K)
    {
    par(mar=c(0.2,3,0.2,1))
    plot(x[,i],type="l",xlab="",xlim=xlim,ylim=if(input==i) NULL else ylim,
      xaxt=if(i < K)"n" else "s")
    }

}
