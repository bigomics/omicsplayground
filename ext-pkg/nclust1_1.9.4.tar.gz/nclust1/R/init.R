.First.lib <- function(libname, pkgname) {
  s <- search()
  library.dynam("nclust",pkgname,libname,now=FALSE)
}
