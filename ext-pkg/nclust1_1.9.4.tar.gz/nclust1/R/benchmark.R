"benchmark" <-
function(n){
print(paste("n = ",n))

x = array(rnorm(n*10),dim=c(n,10))

print(sprintf("elapsed time:"));
print(sprintf("dist   %10.2f",
  system.time(d <- dist(x))[[3]]))

print(sprintf("nclust %10.2f",system.time(o <- nclust(d,height="linkscore",
  branchflip="tightleft"))[[3]]))

print(sprintf("hclust %10.2f",system.time(h <- hclust(d,"ave"))[[3]]))

print(sum(abs(o$merge-h$merge)))
print(sum(abs(o$height-h$height)))
list(o=o,h=h)
}

