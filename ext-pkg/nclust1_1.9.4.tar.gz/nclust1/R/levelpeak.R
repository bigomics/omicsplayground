findpeak <- function( x, smalljump = NULL, bigjump = 10 )
{
  n <- length(x)
  if( is.null(smalljump) ) smalljump <- bigjump * 0.5;
  r <- .C("R_findpeak", as.integer(n), as.integer(x),
    as.double(smalljump), as.double(bigjump), segment = integer(n),
    npeaks = integer(1), peaks = integer(n), 
    ntroughs = integer(1), troughs = integer(n) )
  list( segment = r$segment, peaks = r$peaks[1:(r$npeaks)],
    troughs = r$troughs[1:(r$ntroughs)])
}
