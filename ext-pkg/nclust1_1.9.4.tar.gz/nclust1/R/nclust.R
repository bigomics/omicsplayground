"nclust" <-
function(data,link="ave",
  branchflip="nephew",
  height="loglevel",
  center="col",
  distance="ward",
  impute=TRUE
  ){
  
  is.dist <- function(t)(class(t) == "dist")
  
  if(is.dist(data))
    n <- attr(data,"Size")
  else {
    if(is.matrix(data)) n <- dim(data)[2]
    else stop("can't handle input data type")
    }

  centercode = pmatch(center,c("none","col","row","both")) - 1
  if(centercode < 0 || centercode > 3)
    stop("invalid `center' option")

  linkcode = pmatch(link,
    c("ave","mcquitty", "ward", "single","complete","allpair")) - 1
  if(linkcode < 0 || linkcode > 4 )
    stop("invalid `link' option")

  distancecode = pmatch(distance,
    c("ward","nzcor","euclidean")) - 1
  if( distancecode < 0 || distancecode > 2 )
    stop("invalid `distance' option")
  if( distancecode == 1 )
    stop("distance 'nzcor' not yet implemented")
  
  if(branchflip == "tightleft")
    flip <- 0
  else
    flip <- 1
  
  if(is.na(linkcode))
    stop("invalid clustering method")
  
  if( n <= 2 )
    stop("nclust can not handle fewer than three items")

  if( is.dist(data) )
    r <- .C("Rdist_nclust",
      as.integer(n), as.double(data),

      as.integer(linkcode),
      as.integer(flip),
      
      merge = integer(2*(n-1)),
      linkscore = double(n-1),
      order = integer(n),
      leaf.level = integer(n),
      branch.level = integer(n-1),
      NAOK = TRUE
      )
  else
    r <- .C("R_dmat_nclust",
      as.integer(dim(data)[1]), as.integer(dim(data)[2]), as.double(data),

      as.integer(centercode),
      as.integer(impute),

      as.integer(distancecode),
      as.integer(linkcode),
      as.integer(flip),

      merge = integer(2*(n-1)),
      linkscore = double(n-1),
      order = integer(n),
      leaf.level = integer(n),
      branch.level = integer(n-1),
      n.leaf = integer(n-1),
      sum.level = integer(n-1),
      sumsq.level = double(n-1),
      bounds = integer(2*(n-1)),
      n.leaf.parent = integer(n-1),

      NAOK = TRUE
      )

  dim(r$merge) = c(n-1,2)
  clust <- list(merge = r$merge,order = r$order,
                linkscore = r$linkscore,
                leaf.level = r$leaf.level,
                branch.level = r$branch.level)
  if(is.dist(data))
    clust$labels <- attr(data,"Labels")
  else
    clust$labels <- colnames(data)
    
  attr(clust,"class") <- "hclust"
  
  if(height == "linkscore")
    clust$height <- r$linkscore
  else { 
    clust$height <- -log2(clust$branch.level+1)
    clust$height <- clust$height - min(clust$height)
    }
  if(!is.null(r$n.leaf))
    {
    clust$n.leaf <- r$n.leaf
    clust$sum.level <- r$sum.level
    clust$sumsq.level <- r$sumsq.level
    clust$n.leaf.parent <- r$n.leaf.parent
    }
  if(!is.null(r$bounds))
    { clust$bounds <- r$bounds; dim(clust$bounds) <- c(n-1,2) }
  clust
}


# indices to most variable columns
mostvaridx <- function(x,n) order(
  apply(x,2,function(v)var(v,na.rm=TRUE)),
  decreasing=TRUE)[1:n]

mostvar <- function(x,n) x[,mostvaridx(x,n)]

