# produce a polyline corresponding to the dendrograms h
#
`dendrolines` <-
function(h, hang = 0.1, branchtype = "s", height = NULL){
  if( class(h) != "hclust")
    stop("input has to be an `hclust' class")

  n <- length(h$height)+1
  npoints <- n + 3*(n-1)
  if(branchtype == "s" ) npoints <- npoints + 4*(n-1)
  if(is.null(height) )
    height <- h$height
  else
    if(length(height) != dim(h$merge)[1] )
      stop("supplied height has wrong length")

  r <- .C("R_dendrolines",as.integer(n),
    as.integer(h$merge),
    as.double(height),
    as.double(hang),
    as.integer(ifelse(branchtype == "s",1,0)),
    x = double(npoints),
    y = double(npoints))
  list(x=r$x,y=r$y)  
  }

plot.nclust <-
function(h, hang = 0.1, branchtype = "s", height = NULL ){
  p <- dendrolines(h,hang = hang, branchtype = branchtype, height = height)
  plot.new()
  plot.window( c(min(p$x),max(p$x)), c(min(p$y),max(p$y)) )
  lines(p)
  axis(2)
  invisible(p)
  }
