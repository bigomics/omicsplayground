cplot.points <- function(x, y) {
  points(x, y, cex=0.1)
}

mplot <- function(x, xlim=NULL,margin=0, gutter=0.5,ti=NULL,
  cex.axis=1, band = NULL, panel=cplot.points, fixed.prop = TRUE )
{
  if( is.matrix(x) )
    { m <- dim(x)[1]; n <- dim(x)[2] }
  else
    { m <- 1; n <- length(x); x <- array(x,dim=c(1,n)) }

  if( is.null(xlim) ) xlim <- c(0.5,n+0.5)

  # get the range of each data vector
  rx <- apply(x,1,function(u)range(u,finite=TRUE))
  
  # add margins to the range
  prx <- array(c(1+margin,-margin,-margin,1+margin),dim=c(2,2)) %*% rx

  r <- apply(prx,2,function(u) u[2]-u[1])
  scale <- sum(r)
  
  # add the gutter
  prx <- prx + scale*c(-gutter,gutter)/m
  r <- apply(prx,2,function(u) u[2]-u[1])

  # readjust the scale
  scale <- sum(r)
  offset <- 1-cumsum(r)/scale
  plot.new()
  plot.window(xlim, ylim=c(0,1),xaxs="i")
  panel <- match.fun(panel)
  for(i in 1:m ) {

    panel(1:n, ( x[i,] - prx[1,i] )/scale + offset[i])

    if( !is.null(band) )
      for(j in 1:length(band))
        lines(xlim,(c(band[j],band[j])-prx[1,i])/scale+offset[i],col="red")

    if(is.null(ti))
      ticks <- pretty( rx[,i],n=3 )
    else
      {
      tt <- trunc(rx[,i]/ti)
      ticks <- ti * ((tt[1]-1):(tt[2]+1))
      }
    
    axis(side=2,at=(ticks-prx[1,i])/scale +offset[i],line=1, labels=ticks,las=1,
      cex.axis=cex.axis )

    if( !is.null( rownames(x)[i] ) )
      mtext( rownames(x)[i], side=2, line=4, cex=.8,
        at=((prx[1,i]+prx[2,i])/2-prx[1,i])/scale+offset[i],adj=1,las=1)
    }
}
