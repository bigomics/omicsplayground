
`sclust` <-
function(x, height="logdepth", distance = 0, link = 0){
  n <- nlevels(x[[1]])
  r <- .C("R_smat_nclust",
    as.integer(length(x[[1]])),
    as.integer(n),
    as.integer(x[[1]]),
    as.integer(x[[2]]),
    as.integer(distance),
    as.integer(link),
  
    merge = integer(2*(n-1)),
    linkscore = double(n-1),
    order = integer(n),
    leaf.level = integer(n),
    branch.level = integer(n-1),
    NAOK = TRUE
    )
  
  clust <- list(merge = r$merge, order = r$order,
    linkscore = r$linkscore,
    leaf.level = r$leaf.level+1,
    branch.level = r$branch.level+1)
  dim(clust$merge) = c(n-1,2)
  
  attr(clust,"class") <- "hclust"
  
  clust$labels <- as.character(1:n)
  
  if( height == "linkscore")
    clust$height <- r$linkscore
  else {
    clust$height <- -log2(clust$branch.level)
    clust$height <- clust$height - min(clust$height)
    }
  clust
}

