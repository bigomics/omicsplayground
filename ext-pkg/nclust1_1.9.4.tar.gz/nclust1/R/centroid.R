centroid <- function(x, C)
{
  m <- nrow(C$merge)
  n <- nrow(x)
  y <- array(0,dim=c(n,m))
  rownames(y) <- rownames(x)
  colnames(y) <- paste("m",1:m,sep="")
  for(i in 1:m)
    {
    a <- C$merge[i,1]
    if( a < 0 )
      { xa <- x[,-a]; wa <- 1 }
    else
      { xa <- y[,a]; wa <- C$n.leaf[a] } 
    b <- C$merge[i,2]
    if( b < 0 )
      { xb <- x[,-b]; wb  <- 1 }
    else
      { xb <- y[,b]; wb <- C$n.leaf[b] } 
    y[,i] <- (wa * xa  + wb * xb)/(wa + wb)
    }
  y
}
