/*
 * ndf_mmat.c - multiple data matrix
 *
 * cluster the columns of a set of data matrices, assuming the columns
 * are matched (with potential missing variables in some studies)
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "ndf_mmat.h"

/*
vector of int's 
*/
typedef struct ialloc_struct {
  struct ialloc_struct *next;
  int n_used;
  int n_allocated;
  int data[];
  }
  ialloc_t;

#define IALLOC_BLOCK 4000

static int *
ialloc ( int n, ialloc_t **ialloc_list_ )
{
  ialloc_t *T = *ialloc_list_;
  int *x = NULL;
  if( T == NULL || T->n_used + n > T->n_allocated )
    {
    ialloc_t *U;
    int sz = n < IALLOC_BLOCK ? IALLOC_BLOCK: n;
    U = (ialloc_t*) malloc( sizeof(ialloc_t) + sizeof(int)*sz );
    if( U == NULL ) return NULL;
    U->next = T;
    U->n_used = n;
    U->n_allocated = sz;
    *ialloc_list_ = U;
    x = U->data;
    }
  else
    {
    x = T->data + T->n_used;
    T->n_used += n;
    }
  return x;
}

static void
ialloc_free (ialloc_t *T )
{
  while( T != NULL )
    {
    void *tobefree = T;
    T = T->next;
    free(tobefree);
    }
}


static inline int
n_iunion ( ivec *a, ivec *b )
{
  int n = 0;
  int *pa = a->i;
  int *pb = b->i;
  if(pa == NULL && pb == NULL ) return 0;
  if(pa == NULL) return b->n;
  if(pb == NULL) return a->n;
  for(;;)
    {
    if( *pb == *pa ) { n++; pb++; pa++; }
    else if( *pb < *pa ) { n++; pb++; }
    else if( *pb > *pa ) { n++; pa++; }
    if( pa >= a->i + a->n )
      {
      while( pb++ < b->i + b->n ) n++;
      break;
      }
    if( pb >= b->i + b->n )
      {
      while( pa++ < a->i + a->n ) n++;
      break;
      }
    }
  return n;
}

static void
mmat_nzcor (
  int a,
  int nreq,
  const int *B, const int *J,
  double *D,
  void *ctx )
{
  mmat_t *M = (mmat_t *)ctx;
  int nu = M->nu;
  int K = M->K;
  zmat_t *zeta = M->zmat;
  for(int k = 0; k < K; k++ )
    {
    ivec *nak = M->nainfo[k];
    int nk = M->nrow[k];
    int *idxk = M->idx + k*nu;
    double *x = M->data + M->doff[k];

    int ia = idxk[a]-1;
    if( ia < 0 ) 
      {
      for(int i = 0; i < nreq; i++ )
        zeta[k + i*K].z = zeta[k + i*K].w = 0;
      continue;
      }
    double *xa = x + nk * ia;

    for(int i = 0; i < nreq; i++ )
      {
      int b = B[i];
      int ib = idxk[b] - 1;
      if( ib < 0 )
        {
        zeta[k + i*K].z = zeta[k + i*K].w = 0;
        continue;
        }
      double *xb = x + nk * ib;
      
      double sab = 0;
      for(int j = 0; j < nk; j++ )
        sab += xa[j] * xb[j];
      
      if( nak[ia].n > 0 )
        {
        double sbb = 1;
        for(int u = 0; u < nak[ia].n; u++ )
          {
          double v = xb[ nak[ia].i[u] ];
          sbb -= v*v;
          }
        sab /= sqrt(sbb);
        }
      if( nak[ib].n > 0 )
        {
        double saa = 1;
        for(int u = 0; u < nak[ib].n; u++ )
          {
          double v = xa[ nak[ib].i[u] ];
          saa -= v*v;
          }
        sab /= sqrt(saa);
        }

      // adhoc clamping
      if(sab > MAXCORR ) 
        sab = MAXCORR;
      else if(sab < - MAXCORR )
        sab = -MAXCORR;

      zeta[k + i*K].z = atanh(sab);
      int df = nk - n_iunion( &nak[ia], &nak[ib] );
      zeta[k + i*K].w = (df > 3 ? df-3 : 0);

      }
    }
  
  // 
  // meta-analytical summary
  // TODO: multilevel summarization
  //
  zmat_t *zave = &( zeta[K * nreq] );
  
  if( M->diss == 0 )
    for(int i = 0; i < nreq; i++ )
      {
      double sw = 0, sww = 0, swz = 0, swzz = 0;
      double ns = 0;
      for(int k = 0; k < K; k++ )
        {
        zmat_t *zk = & zeta[ k + i*K ];
        if( zk->w == 0 ) continue;
        ns++;
        sw += zk->w;
        sww += zk->w * zk->w;
        swz += zk->w * zk->z;
        swzz += zk->w * zk->z * zk->z;
        }
      double Q = swzz - swz*swz / sw;
      if( Q > ns-1 )  
        {
        double tau2 = (Q-(ns-1))/(sw-sww/sw);
        sw = swz = 0;
        for(int k = 0; k < K; k++ )
          {
          zmat_t *zk = & zeta[ k + i*K ];
          if( zk->w == 0 ) continue;
          double wrema = 1/(1/zk->w + tau2);
          sw += wrema;
          swz += wrema * zk->z;
          }
        }
      zave[i].z = swz/sw;
      zave[i].w = sw;
      }
  else if( M->diss == 1  )
    for(int i = 0; i < nreq; i++ )
      {
      double sw = 0, swz = 0;
      for(int k = 0; k < K; k++ )
        {
        zmat_t *zk = & zeta[ k + i*K ];
        if( zk->w == 0 ) continue;
        sw += zk->w;
        swz += zk->w * zk->z;
        }
      zave[i].z = swz/sw;
      zave[i].w = sw;
      }

  for(int i = 0; i < nreq; i++ )
    {
    #if 1
    D[J[i]] =  - zave[i].z; 
    #else // use significance
    D[J[i]] = - zave[i].z * sqrt(zave[i].w);
    #endif

    if( isnan( D[J[i]] ) )
      D[J[i]] = 0;

    if( M->pwdist )
      M->pwdist[nu * a + B[i] ] = M->pwdist[nu * B[i] + a ] = D[J[i]];
    }
}

/*
 * callback for branchflip()
 *
 */

typedef struct {
  mmat_t *M;
  
  // centroid data
  double **C;        // concatenated for all study
  double *w;         // weights for the centroid
  int ni;            // next index

  // temporary pointer to strata data
  double **xa;
  double **xb;
  double **xc;
} mcentroid_t;

mcentroid_t *
mcentroid_context_new ( mmat_t *M )
{
  mcentroid_t *c = (mcentroid_t*)malloc(sizeof(*c));
  c->M = M;
  c->C = (double**)malloc( sizeof(double*) * M->nu );
  c->w = (double*)malloc( sizeof(double) * M->nu );
  c->ni = 0;
  
  c->xa = (double**)malloc(sizeof(double*) * M->K * 3);
  c->xb = c->xa + M->K;
  c->xc = c->xb + M->K;
  return c;
}

void
mcentroid_context_free ( mcentroid_t *c )
{
  free(c->xa);
  free(c->C);
  free(c->w);
  free(c);
}

void
mcentroid_free (int a, void *ctx)
{
  mcentroid_t *c = (mcentroid_t*)ctx;
  if( a <= 0 )
    return;
  free( c->C[a] );
}

static double *
getdata( mmat_t *M, int k, int a )
{
  int ia = M->idx[ k * M->nu + a] - 1;
  if( ia < 0 ) return NULL;
  return M->data + M->doff[k] + M->nrow[k]*ia;
}

double
mcentroid_diss ( int a, int b, void *ctx )
{
  mcentroid_t *c = (mcentroid_t*)ctx;
  mmat_t *M = c->M;
  int K = M->K;

  double **xa = c->xa, **xb = c->xb;
  if( a < 0 )
    {
    for(int k = 0; k < K; k++ )
      xa[k] = getdata(M,k,-a-1);
    }
  else
    {
    xa[0] = c->C[a];
    for(int k = 1; k < K; k++ )
      xa[k] = xa[k-1] + M->nrow[k-1];
    }
  if( b < 0 )
    {
    for(int k = 0; k < K; k++ )
      xb[k] = getdata(M,k,-b-1);
    }
  else
    {
    xb[0] = c->C[b];
    for(int k = 1; k < K; k++ )
      xb[k] = xb[k-1] + M->nrow[k-1];
    }

  // we'll just use pooled correlation (TODO: replace by RE corr?)
  double sab = 0, saa = 0, sbb = 0;
  for(int k = 0; k < K; k++ )
    {
    double *xak = xa[k], *xbk = xb[k];
    for(int i = 0; i < M->nrow[k]; i++ )
      {
      if( !xak || !xbk || isnan(xak[i]) || isnan(xbk[i]) ) continue;
      sab += xak[i]*xbk[i];
      saa += xak[i]*xak[i];
      sbb += xbk[i]*xbk[i];
      }
    } 
  if( saa > 0 && sbb > 0 )
    return 1 - sab/sqrt(saa*sbb);
  else
    return 0;
}

int
mcentroid_merge (int a, int b, void *ctx)
{
  if( b == 0 ) return a;  // request id for terminal node
  
  mcentroid_t *c = (mcentroid_t*) ctx;
  mmat_t *M = c->M;
  int K = M->K;

  double **xa = c->xa, **xb = c->xb, **xc = c->xc;
  double wa, wb;
  if( a < 0 )
    {
    for(int k = 0; k < K; k++ )
      xa[k] = getdata(M,k,-a-1);
    wa = 1;
    }
  else
    {
    xa[0] = c->C[a];
    for(int k = 1; k < K; k++ )
      xa[k] = xa[k-1] + M->nrow[k-1];
    wa = c->w[a];
    }
  if( b < 0 )
    {
    for(int k = 0; k < K; k++ )
      xb[k] = getdata(M,k,-b-1);
    wb = 1;
    }
  else
    {
    xb[0] = c->C[b];
    for(int k = 1; k < K; k++ )
      xb[k] = xb[k-1] + M->nrow[k-1];
    wb = c->w[b];
    }

  c->ni++;
  int i = c->ni;
  int N = 0;
  for(int k = 0; k < K; k++ ) N += M->nrow[k];
  c->C[i] = (double*)malloc(sizeof(double) * N );
  xc[0] = c->C[i];
  for(int k = 1; k < K; k++ )
    xc[k] = xc[k-1] + M->nrow[k-1];

  double sumw = wa + wb; 
  c->w[i] = sumw;
  for( int k = 0; k < K; k++ )
    {
    double *xak = xa[k], *xbk = xb[k], *xck = xc[k];
    for(int i = 0; i < M->nrow[k]; i++ )
      {
      if( (xak && !isnan(xak[i])) && (xbk && !isnan(xbk[i])) )
        xck[i] = (wa * xak[i] + wb * xbk[i])/sumw;
      else if( (xak && isnan(xak[i])) && (xbk && !isnan(xbk[i])) )
        xck[i] = xbk[i];
      else if( (xak && !isnan(xak[i])) && (xbk && isnan(xbk[i])) )
        xck[i] = xak[i];
      else
        xck[i] = NAN;
      }
    }
  return i;
}

/*
 * Wrapper for R's ".C" function call
 *
 */

void
R_mmat_nclust ( 
  // input
  int *K_, int *nrow, int *ncol,
  int *n_unicol_, int *idx,   // union of cols, and its index
  double *data,
  
  // TODO: input study-level covariates (e.g. hierarchical stratification)

  // options
  int *disscode_,
  int *linkcode_,
  int *bflipcode_,

  // output
  double *s2, int *df, // total variance and df of the columns

  int *merge,
  double *linkscore,
  int *order,
  int *leaf_level,
  int *branch_level,
  int *n_leaf,
  int *sum_level,
  double *sumsq_level,
  int *bounds,
  int *n_leaf_parent,

  int *savepwdist_,
  double *pwdist
  )
{
  int K = *K_;

  int *coff = (int*)malloc(sizeof(int)*2*(K+1));
  int *doff = coff + K+1;
  coff[0] = doff[0] = 0;
  for(int k = 0; k < K; k++ )
    {
    coff[k+1] = coff[k] + ncol[k];
    doff[k+1] = doff[k] + nrow[k]*ncol[k];
    }

  // column centering
  double *x = data;
  for(int k = 0; k < K; k++ )
    for(int i = 0; i < ncol[k]; i++ )
      {
      double mu = 0, N = 0;
      for(int j = 0; j < nrow[k]; j++ )
        if( isfinite(x[j]) )
          { mu += x[j]; N++; }
      mu /= N;
      for(int j = 0; j < nrow[k]; j++ )
        if( isfinite(x[j]) )
          x[j] -= mu;
      x += nrow[k]; 
      }

  // compute overall variance and d.f. (using simple pooling after
  // mean centering)
  int nu = *n_unicol_;
  for(int k = 0; k < K; k++ )
    for(int i = 0; i < nu; i++ )
      {
      int ii = idx[k*nu + i]-1;
      if( ii < 0 ) continue;
      x = data + doff[k] + nrow[k]*ii;
      int dfik = 0;
      for(int j = 0; j < nrow[k]; j++ )
        if( isfinite(x[j]) )
          {
          s2[i] += x[j]*x[j];
          df[i]++; dfik++;
          }
      if(dfik > 1) df[i]--;
      }
  
  for(int i = 0; i < nu; i++ )
    s2[i] /= df[i];

  // The above information are not used. We just do here it to make it
  // easier for selecting relevant columns in subsequent row clustering
  //
  // weights of vars for distance between cases
  // - this is still an open question
  // - filtering (e.g. 33% most variable) is a binary weighting scheme
  // - most likely the weights are sigmoidal, such as the complement of
  //   weights in robust statistics (i.e. we want to use the outliers
  //   instead of the signal)


  /* Standardize each column.dataset and record missing value indices
   */
  ivec *na = (ivec*) malloc (sizeof(ivec)*coff[K]);
  ivec **nainfo = (ivec**) malloc(sizeof(ivec*) * K );
  ialloc_t *idblock = NULL;

  for(int k = 0; k < K; k++ )
    {
    ivec *nak = nainfo[k] = & na[coff[k]];
    double *x = data + doff[k];
    for(int i = 0; i < ncol[k]; i++ )
      {
      double *xi = x + i * nrow[k];
      double sxx = 0;
      nak[i].n = 0;
      for(int j = 0; j < nrow[k]; j++ )
        if(isfinite( xi[j] ) )
          sxx += xi[j]*xi[j];
        else
          nak[i].n++;

      // allocate space for NA indices
      if( nak[i].n == 0 )
        nak[i].i = NULL;
      else
        nak[i].i = ialloc ( nak[i].n, &idblock );

      sxx = sqrt(sxx);
      int u = 0;
      for(int j = 0; j < nrow[k]; j++ )
        if( isfinite(xi[j]) )
          xi[j] /= sxx;
        else
          {
          xi[j] = 0;
          nak[i].i[u++] = j;
          }
      } // column

    } // dataset

  #if 0
  {
  ialloc_t *T = idblock;
  int i = 0;
  while( T )
    {
    fprintf(stderr,"%d %x\n", ++i, T->next );
    T = T->next;
    }
  for(int i = 0; i < nu; i++ )
    {
    fprintf(stderr,"%d: %d: ",i, nainfo[0][i].n);
    for(int j = 0; j < nainfo[0][i].n; j++ )
      fprintf(stderr,"%d ",nainfo[0][i].i[j]);
    fputc('\n',stderr);
    } 
  }
  #endif

  // call nclust
  mmat_t ctx;
  ctx.K = K;
  ctx.nrow = nrow;
  ctx.coff = coff;
  ctx.doff = doff;
  ctx.nu = nu;
  ctx.idx = idx;
  ctx.data = data;
  ctx.nainfo = nainfo;
  ctx.diss = *disscode_;
  ctx.zmat = (zmat_t*)malloc(sizeof(zmat_t)*nu*(K+1) );


  if( *savepwdist_ ) 
    ctx.pwdist = pwdist;
  else 
    ctx.pwdist = NULL;

  mergetree_t *the_tree = alloc_mergetree(nu);

  nclust( nu, mmat_nzcor, &ctx, *linkcode_, the_tree );
  mergetree_sort( the_tree, NULL );

  // branchflip
  if( *bflipcode_ == 0 )
    {
    mcentroid_t *ct = mcentroid_context_new ( &ctx );
    nearest_nephew( the_tree, mcentroid_merge, mcentroid_diss, mcentroid_free, ct );
    mcentroid_context_free ( ct );
    }

  // tree info
  int maxlevel;
  mergetree_node_info( the_tree, order, leaf_level,
    branch_level, n_leaf, sum_level, sumsq_level, &maxlevel );

  convert_to_Rformat( the_tree, merge, linkscore ); 
  
  // this overwrites the_tree, but we already save the results above
  mergetree_bounding_leaf( the_tree, order, bounds, bounds+nu-1 );

  // copy the parent's n_leaf, make the root the parent of itself
  for(int i = nu-2; i >= 0; i-- )
    {
    // left child
    if(merge[i] > 0 )
      n_leaf_parent[ merge[i]-1 ] = n_leaf[i];
    // right child
    if(merge[nu-1+i] > 0 )
      n_leaf_parent[ merge[nu-1+i]-1 ] = n_leaf[i];
    }
  n_leaf_parent[ nu-2 ] = n_leaf[ nu-2 ];

  free(the_tree);
  free(ctx.zmat);
  free(na); free(nainfo);
  ialloc_free(idblock);
  free(coff);
}
