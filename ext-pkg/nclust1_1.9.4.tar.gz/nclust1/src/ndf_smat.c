/*
 *
 *
 */

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "nclust.h"
#include "branchflip.h"
#include "ndf_smat.h"

static inline int
isrt_iai_ ( int n, int *x , const int *y ) { int i, j; for( i = 1; i < n; i++ )
{ int temp = x[i]; for( j = i; j > 0 && ((y[temp]) < (y[x[j-1]])); j-- ) x[j] =
x[j-1]; x[j] = temp; } return n; }

static int
msrt_iai_ ( int n, int *x , const int *y ) { for( int j = 0; j < n; j += 32 )
isrt_iai_ ( (n-j < 32 ? n-j:32), x + j , y ); if( n <= 32 ) return n; int *temp
= (int *)malloc( sizeof(*temp) * n ); if(!temp) return 0; int *u = x; int *v =
temp; for( int m = 32; m < n; m += m ) { for ( int a = 0; a < n; a += m + m ) {
int b = a + m, c; if( b < n ) { c = b + m; if (c > n) c = n; } else b = c = n;
int i = a, j = b; for ( int k = a; k < c; k++ ) { if( i < b ) { if( j < c ) {
if( ((y[u[i]]) <= (y[u[j]]))) v[k] = u[i++]; else v[k] = u[j++]; } else v[k] =
u[i++]; } else v[k] = u[j++]; } } void *t = u; u = v; v = t; } if( u == temp )
memcpy( x, temp, sizeof(*temp)*n); free(temp); return n; }

typedef struct{
  int **p;
  int *n;
  } smat_t;

static int
ncomm ( int na, int *pa, int nb, int *pb )
{
  int nab = 0, i = 0, j = 0;
  for( ; i < na; i++ )
    {
    for( ; j < nb && (pb[j] < pa[i]) ; j++ )
      ;
    if( j >= nb ) break;
    if( pb[j] == pa[i] )
      nab++;
    }
  return nab;
}

static void
scorr (
  int a,
  int nreq,
  const int *B, const int *J,
  double *D,
  void *ctx )
{
  if( nreq == 0 )
    fprintf(stderr,"hey!\n");
  smat_t *S = (smat_t*)ctx;
  int *pa = S->p[a];
  int na = S->n[a];
  for(int k = 0; k < nreq; k++ )
    {
    int *pb = S->p[B[k]];
    int nb = S->n[B[k]];
    D[J[k]] = 1 - ncomm(na, pa, nb, pb)/sqrt(na*nb);
    // fprintf(stderr,"%d %d: %g\n", a, B[k],D[J[k]]);
    }
  // fprintf(stderr,"a = %d, nreq = %d\n", a, nreq);
}


void
smat_nclust (
  int m,          // pairs
  const int *level1, const int *level2, // m-vector of 'levels'
  double *x,      // (optional) m non-zero values
  int distance,   // 0: 1-cosine, TODO: 1, 1-Jaccard

  // output
  int link,       // link function
  mergetree_t *T
  )
{
  int *o = (int*)malloc(sizeof(int)*m);
  for(int i = 0; i < m; i++ )
    o[i] = i;
  msrt_iai_ ( m, o, level2 );
  msrt_iai_ ( m, o, level1 );

  int n1 = 1;
  for(int i = 0; i < m-1; i++ )
    if(level1[o[i]] != level1[o[i+1]])
      n1++;

  smat_t C;
  C.p = (int**)malloc(sizeof(int*)*n1);
  C.n = (int*)malloc(sizeof(int)*n1);
  int *ol2 = (int*)malloc(sizeof(int)*m);
  for(int i = 0; i < m; i++ )
    ol2[i] = level2[o[i]];

  int j = 0, k = 0;
  C.p[0] = ol2;
  for(int i = 0; i < m-1; i++)
    {
    k++;
    if(level1[o[i]] != level1[o[i+1]])
      {
      j++;
      C.p[j] = & ol2[i+1]; 
      C.n[j-1] = k;
      k = 0;
      }
    }
  C.n[j] = k+1;

#if 0
FILE *f = fopen("foo","w");
for(int i = 0; i < n1; i++ )
{
  for(int j = 0; j < n1; j++ )
    {
    double D; int J = 0;
    scorr( i, 1, &j, &J, &D, &C );
    fprintf(f,"%g%c", D, j == n1-1 ? '\n' : '\t');
    }
}
#endif

  nclust( n1, scorr, &C, link, T );

  free(ol2); free(C.n); free(C.p); free(o);
}

void
R_smat_nclust (const int *m_,
  const int *nlevel1_,
  const int *level1, const int *level2,
  const int *distance_, 

  const int *link_,
  
  int *merge, double *height,
  int *order, int *leaf_level, int *branch_level
  )
{
  int n1 = *nlevel1_;
  mergetree_t *T = alloc_mergetree(n1);

  smat_nclust(
    *m_, level1, level2, 0,                        // input
    *distance_, *link_,                            // options
    T );                                          // output
  mergetree_sort( T, NULL );

  int maxlevel;
  mergetree_node_info( T, order, leaf_level,
    branch_level, 0,0, 0, &maxlevel );

  convert_to_Rformat( T, merge, height );
  free(T);
}
