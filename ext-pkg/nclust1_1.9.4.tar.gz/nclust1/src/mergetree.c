/*
 * mergetree.c
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "mergetree.h"

static inline int isrt_iad_ ( int n, int *x , const double *y ) { int i, j;
for( i = 1; i < n; i++ ) { int temp = x[i]; for( j = i; j > 0 && ((y[temp]) <
(y[x[j-1]])); j-- ) x[j] = x[j-1]; x[j] = temp; } return n; }

static int msrt_iad_ ( int n, int *x , const double *y ) { for( int j = 0; j <
n; j += 32 ) isrt_iad_ ( (n-j < 32 ? n-j:32), x + j , y ); if( n <= 32 ) return
n; int *temp = (int *)malloc( sizeof(*temp) * n ); if(!temp) return 0; int *u =
x; int *v = temp; for( int m = 32; m < n; m += m ) { for ( int a = 0; a < n; a
+= m + m ) { int b = a + m, c; if( b < n ) { c = b + m; if (c > n) c = n; }
else b = c = n; int i = a, j = b; for ( int k = a; k < c; k++ ) { if( i < b ) {
if( j < c ) { if( ((y[u[i]]) <= (y[u[j]]))) v[k] = u[i++]; else v[k] = u[j++];
} else v[k] = u[i++]; } else v[k] = u[j++]; } } void *t = u; u = v; v = t; }
if( u == temp ) memcpy( x, temp, sizeof(*temp)*n); free(temp); return n; }


mergetree_t*
alloc_mergetree (int N)
{
  mergetree_t *T = (mergetree_t*)malloc(sizeof(*T)*(N));
  if(!T) return NULL;
  T[0].left = N;
  T[0].right = 0; // unused, but make it sane when saved to file
  T[0].height = 0;
  return T;
}

void
mergetree_sort (mergetree_t *T, mergetree_t *U)
{
	int N = T[0].left;
	int *o = (int*)malloc(sizeof(int)*2*N);

	double *h = (double*)malloc(sizeof(double)*N);
	for(int i = 1; i < N; i++ )
		{ o[i] = i; h[i] = (T[i].left > T[i].right? T[i].left : T[i].right); }
	msrt_iad_ ( N-1, o+1, h );
	for(int i = 1; i < N; i++ )
		h[i] = T[i].height;
	msrt_iad_ ( N-1, o+1, h );
	free(h);

	int *io = o + N; // inverse ordering
	for(int i = 1; i < N; i++ )
		io[o[i]] = i;

	mergetree_t* V = alloc_mergetree(N);
	for(int i = 1; i < N; i++ )
		{
		int j = o[i];
		V[i].height = T[j].height;
		V[i].left = (T[j].left < 0 ? T[j].left : io[T[j].left]);
		V[i].right = (T[j].right < 0 ? T[j].right : io[T[j].right]);
		}
		
	if(U)
		for(int i = 1; i < N; i++ )
			U[i] = V[i];
	else
		for(int i = 1; i < N; i++ )
			T[i] = V[i];

	free(V);
	free(o);
}

void
mergetree_save ( mergetree_t *T, char *filename )
{
  int n = T[0].left;
  FILE *F = fopen(filename,"w");
  if(!F)
    fprintf(stderr,"can't save mergetree to %s\n", filename );

  for(int i = 0; i < n; i++ )
    fprintf(F,"%d\t%d\t%g\n", T[i].left,T[i].right,T[i].height);
  fclose(F);
}

mergetree_t *
mergetree_load ( char *filename )
{
  FILE *F = fopen( filename, "r" );
  if(!F)
    { 
    fprintf(stderr,"can't read mergetree from file %s\n", filename );
    return NULL;
    }
  int n;
  if( 1 != fscanf(F," %d %*d %*f", &n ) || n <= 0 )
    { fprintf(stderr,"error loading mergetree %s\n", filename); return NULL; }
  mergetree_t *T = (mergetree_t*)malloc(sizeof(*T) * n);
  T[0].left = n;
  T[0].right = 0;
  T[0].height = 0;
  for(int i = 1;i < n; i++ )
    if( 3 != fscanf(F," %d %d %lf", &T[i].left, &T[i].right, &T[i].height ) )
      { fprintf(stderr,"mergetree_load: error reading node %d\n",i); exit(1); }
  fclose(F);
  return T;
}

/*
Collect various information about the nodes. 
*/
int
mergetree_node_info (
  mergetree_t *T, int *ordering, 
  
  // leaf properties
  int *leaf_level,
  
  // branch properties
  int *branch_level,   // level of a branch (root is zero)
  int *n_leaf,         // number of leaf nodes under a branch
  int *sum_level,      // sums of the levels of leafs under a branch
  double *sumsq_level,    // sums of squared levels of leafs under a branch

  // global properties
  int *maxlevel_
  )
{
  int N = T[0].left;
  int *stack = (int*)malloc(sizeof(int)*N);
  int maxlevel = -1;
  int status = 0; // return status
  int level = 0, k = 0;
  int p = 0; stack[p] = N-1;
  int prev = 0;
  while( p >= 0 )
    {
    int i = stack[p];
    if( i > 0 )         // i is an internal node
      {
      if( T[i].left == prev )  // return from the left child
        {
        stack[++p] = T[i].right;
        }
      else if ( T[i].right == prev ) // return from the right child
        {
        level--;
        if(branch_level)
          branch_level[i-1] = level;
        if(n_leaf)
          {
          n_leaf[i-1] = (T[i].left < 0 ? 1 : n_leaf[T[i].left - 1])
                      + (T[i].right < 0 ? 1 : n_leaf[T[i].right - 1]);
          if(sum_level)
            sum_level[i-1] = (T[i].left < 0 ? level+1 : sum_level[T[i].left-1])
                        + (T[i].right < 0 ? level+1 : sum_level[T[i].right-1]);
          if(sumsq_level)
            {
            double ssqleft = T[i].left < 0 ? (level+1)*(level+1)
                                           : sumsq_level[T[i].left-1];
            double ssqright = T[i].right < 0 ? (level+1)*(level+1)
                                           : sumsq_level[T[i].right-1];
            sumsq_level[i-1] = ssqleft + ssqright;
            }
          }
        p--;
        }
      else        // enter from the parent
        {
        level++;
        if( p > N - 2 ) { status = 2; break; } // corrupt tree: overflow
        stack[++p] = T[i].left;
        }
      }
    else                // i is a terminal node
      {
      if( k >= N ) { status = 1; break; } // corrupt tree: too many leafs
      
      if( ordering )
        ordering[k] = -i;
      if( leaf_level )
        leaf_level[k] = level;
      k++;
      if( maxlevel < level )
        maxlevel = level;
      p--;
      }
    prev = i;
    }
  free(stack);
  if(maxlevel_ ) *maxlevel_ = maxlevel;
  return status;
}

/* Find the left- and rightmost terminal nodes corresponding
 * to the branches.
 *
 */
void
mergetree_bounding_leaf(
  mergetree_t *T, int *ordering,
  int *l_oid, int *r_oid     // index to ordered leafs
  )
{
  int n = T[0].left;

  // inverse ordering
  int *iord = (int*) malloc ( sizeof(int) * (n+1) );
  for(int i = 1; i <= n; i++ )
    iord[ordering[i-1]] = i;

  // bubble up the bounds
  int *stack = (int*) malloc( sizeof(int) * n );
  for(int i = 1; i < n; i++ )
    {
    if( T[i].left > 0 )
      {
      int j = i;
      int p = 0;
      while( j > 0 )
        {
        stack[p++] = j;
        j = T[j].left;
        }
      while( p > 0 )
        T[stack[--p]].left = j;
      }
    if( T[i].right > 0 )
      {
      int j = i;
      int p = 0;
      while( j > 0 )
        {
        stack[p++] = j;
        j = T[j].right;
        }
      while( p > 0 )
        T[stack[--p]].right = j;
      }
    }

  for(int i = 0; i < n-1; i++ )
    {
    l_oid[i] = iord[-T[i+1].left];
    r_oid[i] = iord[-T[i+1].right];
    }
  free(stack);
  free(iord);
}
