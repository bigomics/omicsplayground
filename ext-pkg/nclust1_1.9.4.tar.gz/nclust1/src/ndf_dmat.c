/*
ndf_dmat.c - apply nclust() to clustering of dense data matrix

The implemented distances are
* Ward = 1 - cor
* nzcorr = -atanh(cor)
* Euclidean

Those involving cor has an option to mean-centering the vector of the
clustered object.

*/
#include <math.h>
#include <stdio.h>

#include "nclust.h"
#include "branchflip.h"
#include "ndf_dmat.h"

typedef struct {
  int n, m;
  double *x;
  } dmat_t;

// ward distance (1 - corr) with possible missing values
static void 
ward_na (
  int a,
  int nreq,
  const int *B, const int *J,
  double *D,
  void *ctx )
{
  int m = ((dmat_t*)ctx)->m;
  double *x = ((dmat_t*)ctx)->x;
  double *xa = x + a*m;
  for(int k = 0; k < nreq; k++ )
    {
    double *xb = x + B[k]*m;
    double ab = 0, ssa = 0, ssb = 0;
    for(int j = 0; j < m; j++ )
      if(isfinite(xa[j]) && isfinite(xb[j]))
        { 
        ab += xa[j] * xb[j];
        ssa += xa[j] * xa[j];
        ssb += xb[j] * xb[j];
        }
    if( ssa > 0 && ssb > 0 )
      D[J[k]] = 1 - ab/sqrt(ssa*ssb);
    else
      D[J[k]] = 1;
    }
}

// ward distance with no missing values, assume input matrix
// is already scaled such that ||x_i||_2 = 1
static void 
ward (
  int a,
  int nreq,
  const int *B, const int *J,
  double *D,
  void *ctx )
{
  int m = ((dmat_t*)ctx)->m;
  double *x = ((dmat_t*)ctx)->x;
  double *xa = x + a*m;
  for(int k = 0; k < nreq; k++ )
    {
    double *xb = x + B[k]*m;
    double ab = 0;
    for(int j = 0; j < m; j++ )
      ab += xa[j] * xb[j];
    D[J[k]] = 1.0 - ab;
    }
}

// euclidean distance with no missing values
static void 
euclidean (
  int a,
  int nreq,
  const int *B, const int *J,
  double *D,
  void *ctx )
{
  int m = ((dmat_t*)ctx)->m;
  double *x = ((dmat_t*)ctx)->x;
  double *xa = x + a*m;
  for(int k = 0; k < nreq; k++ )
    {
    double *xb = x + B[k]*m;
    double d2 = 0;
    for(int j = 0; j < m; j++ )
      {
      double v = xa[j] - xb[j];
      d2 += v*v;
      }
    if(d2 < 0 ) d2 = 0;
    D[J[k]] = sqrt(d2);
    }
}
/*
context struct and callbacks for nearest_nephew()

*/
typedef struct
  {
  int n;
  int m;
  double *x;
  int distance;

  double **C;  // centroids for internal node
  double *w;   // weights of the cluster
  int ni;      // next index
  }
centroid_t;

void
centroid_free (int a, void *ctx )
{
  centroid_t *c = (centroid_t*)ctx;
  if( a <= 0 )
    return;

  free( c->C[a] );
}

double
centroid_diss (int a, int b, void *ctx )
{
  centroid_t *c = (centroid_t*)ctx;
  int m = c->m;
  double *x = c->x;
  double *xa, *xb;
  if( a < 0 )
    xa = x + (-a-1) * m;
  else
    xa = c->C[a];
  if( b < 0 )
    xb = x + (-b-1) * m; 
  else
    xb = c->C[b];

  if( c->distance == 0 )
    {
    double ab = 0, ssa = 0, ssb = 0;
    for(int j = 0; j < m; j++ )
      if( isfinite(xa[j]) && isfinite(xb[j])) 
        {
        ab += xa[j] * xb[j];
        ssa += xa[j] * xa[j];
        ssb += xb[j] * xb[j];
        }
    if( ssa > 0 && ssb > 0 )
      return 1 - ab/sqrt(ssa*ssb);
    else
      return 1;
    }
  else if( c->distance == 2 )
    {
    double d2 = 0;
    for(int j = 0; j < m; j++ )
      {
      double v = xa[j] - xb[j];
      d2 += v*v;
      }
    if(d2 < 0 ) d2 = 0;
    return sqrt( d2 );
    }
  else
    return NAN; // should never reach this
}

int
centroid_merge ( int a, int b, void *ctx )
{
  if( b == 0 ) return a;
  
  centroid_t *c = (centroid_t*)ctx;
  c->ni++;
  int i = c->ni;
  int m = c->m;
  double *x = c->x;
  double *xi = c->C[i] = (double*)malloc(sizeof(double) * m );
  double *xa, *xb, wa, wb;
  if( a < 0 )
    { xa = x + (-a-1) * m; wa = 1; }
  else
    { xa = c->C[a]; wa = c->w[a]; }

  if( b < 0 )
    { xb = x + (-b-1) * m; wb = 1; }
  else
    { xb = c->C[b]; wb = c->w[b]; }
    
  double sumw = wa + wb;
  c->w[i] = sumw;
  for(int j = 0; j < c->m; j++ )
    xi[j] = (wa * xa[j] + wb * xb[j])/sumw;
  
  return i;
}

void
dmat_nclust (
  int m,   // features 
  int n,   // items to be clustered
  double *x, // data matrix, features are contiguous in memory
  int centering,
  int impute,
  int distance, // 0: Ward, 1: -zcorr, 2: Euclidean
  
  int link,  // tree link function
  mergetree_t *T
  )
{
  int notfinite = 0;
  
  if( 0x1 & centering )  // centering items (rows here, cols in R/Fortran)
    {
    double *xi = x;
    for(int i = 0; i < n; i++, xi += m )
      {
      double sum = 0, mi = 0;
      for(int j = 0; j < m; j++ )
        if(isfinite(xi[j]))
          {
          mi++;
          sum += xi[j];
          }
        else
          notfinite++;


      double mean_i = sum / mi;
      for(int j = 0; j < m; j++ )
        if( isfinite(xi[j]) )
          xi[j] -= mean_i;
        else
          if(impute)
            xi[j] = 0;
      }
    }

  if( 0x2 & centering ) // centering features (cols here, rows in R/Fortran)
    {
    double *sum = (double*)malloc(sizeof(double)*m*2);
    double *num = sum + m;
    for(int j = 0; j < m; j++ )
      sum[j] = num[j] = 0;
    double *xi = x;
    for(int i = 0; i < n; i++, xi += m )
      {
      for(int j = 0; j < m; j++ )
        if(isfinite(xi[j]))
          {
          sum[j] += xi[j];
          num[j]++;
          }
      }
    for(int j = 0; j < m; j++ )
      sum[j] /= num[j];
    xi = x;
    for(int i = 0; i < n; i++, xi += m )
      for(int j = 0; j < m; j++ )
        if(isfinite(xi[j]))
          xi[j] -= sum[j];
        else
          if(impute) xi[j] = 0;
    
    free(sum);
    }

  // impute non-centered data, use the mean of each item.
  //
  if( impute && 0 == centering ) 
    {
    double *xi = x;
    for(int i = 0; i < n; i++, xi += m )
      {
      double sum = 0; int mi = 0;
      for(int j = 0; j < m; j++ )
        if(isfinite(xi[j]))
          { sum += xi[j]; mi++; }
      double mean_i = sum / mi;
      if( mi < m )
        for(int j = 0; j < m; j++ )
          xi[j] = mean_i;
      }
    }
  
  if( !impute && 0 == centering )
    notfinite = 1;

  if( impute ) notfinite = 0;

  // pre-scale such that the 2-norm == 1, allowing to compute
  // correlations using just the dot product
  //
  if( notfinite == 0 && (distance == 0 || distance == 1) )
    {
    double *xi = x;
    for(int i = 0; i < n; i++, xi += m )
      {
      double ssx = 0;
      for(int j = 0; j < m; j++ )
        ssx += xi[j]*xi[j];
      double norm2x = sqrt(ssx);
      if(norm2x > 0 )
        for(int j = 0; j < m; j++ )
          xi[j] /= norm2x;
      }
    }
  
  dmat_t ctx;
  ctx.n = n;
  ctx.m = m;
  ctx.x = x;

  if( distance == WARD_D )
    nclust( n, notfinite > 0 ? ward_na : ward, &ctx, link, T );
  #if 0 // to be implemented
  else if( distance == MZCOR )
    nclust( n, notfinite > 0 ? zcorr_na : zcorr, &ctx, link, T );
  #endif
  else if(distance == EUCLIDEAN )
    nclust( n, euclidean, &ctx, link, T );
}

void
R_dmat_nclust (int *m_, int *n_, double *x,
  int *center_,
  int *impute_,
  int *distance_, 

  int *link_,
  int *branchflip_,
  
  int *merge, double *height, 
  int *order, int *leaf_level, int *branch_level,
  int *n_leaf, int *sum_level, double *sumsq_level,
  int *bounds, int *n_leaf_parent
  )
{
  int n = *n_;
  mergetree_t *T = alloc_mergetree(n);
  dmat_nclust (
    *m_, n, x,                                    // input
    *center_, *impute_, *distance_, *link_,       // options
    T );                                          // output
  mergetree_sort( T, NULL );

  if(*branchflip_ == 1 )
    {
    centroid_t ct;
    centroid_t *c = &ct;
    c->n = n;
    c->m = *m_;
    c->x = x;
    c->C = (double**)malloc(sizeof(double*) * n);
    c->w = (double*)malloc(sizeof(double) * n);
    c->ni = 0;
    c->distance = *distance_;
    
    nearest_nephew ( T, centroid_merge, centroid_diss, centroid_free, c);

    free(c->C);
    free(c->w);
    }

  int maxlevel;
  mergetree_node_info( T, order, leaf_level,
    branch_level, n_leaf, sum_level, sumsq_level, &maxlevel );

  convert_to_Rformat( T, merge, height );

  // this overwrites T, but we already save the results above
  mergetree_bounding_leaf( T, order, bounds, bounds+n-1 );
  free(T);

  // copy the parent's n_leaf, make the root the parent of itself
  for(int i = n-2; i >= 0; i-- )
    {
    // left child
    if(merge[i] > 0 )
      n_leaf_parent[ merge[i]-1 ] = n_leaf[i];
    // right child
    if(merge[n-1+i] > 0 )
      n_leaf_parent[ merge[n-1+i]-1 ] = n_leaf[i];
    }
  n_leaf_parent[ n-2 ] = n_leaf[ n-2 ];
}
