/*
 * dpq.c - double-ended priority queue
 *
 * implementation of "dpq.h"
 */

#include <stdlib.h>
#include <math.h>

#include <stdio.h>

#include "dpq.h"

dpq_t *
dpq_alloc ( int maxnodes )
{
  dpq_t *Q = (dpq_t*) malloc( sizeof(dpq_t) * (maxnodes+1));
  if(Q) Q[0].b = maxnodes;
  return dpq_init ( Q );
}

void
dpq_up_L ( dpq_t *Q, int i )
{
  double u = Q[i].u; int a = Q[i].a;
  int j;
  while( u < Q[ j = i/2 ].u )
    {
    Q[i].u = Q[j].u; Q[i].a = Q[j].a;
    i = j;
    }
  Q[i].u = u; Q[i].a = a;
}

void
dpq_up_R ( dpq_t *Q, int i )
{
  double v = Q[i].v; int b = Q[i].b;
  int j;
  while( v > Q[ j = i/2 ].v )
    {
    Q[i].v = Q[j].v; Q[i].b = Q[j].b;
    i = j;
    }
  Q[i].v = v; Q[i].b = b;
}

void
dpq_down_L (dpq_t *Q, int i )
{
  int n = dpq_nitems(Q);
  int m = dpq_nnodes(Q);
  double u = Q[i].u;
  int a = Q[i].a;
  while( i <= m/2 )
    {
    int j = 2*i;
    int k = j+1;
    if( k <= m && Q[k].u <= Q[j].u ) j = k;
    if( u <= Q[j].u ) break;
    Q[i].u = Q[j].u; Q[i].a = Q[j].a;
    if( 2*j <= n && u > Q[j].v )
      {
      double t = Q[j].v; int c = Q[j].b;
      Q[j].v = u; Q[j].b = a;
      u = t; a = c;
      }
    i = j;
    }
  Q[i].u = u; Q[i].a = a;
}

void
dpq_down_R (dpq_t *Q, int i )
{
  int n = dpq_nitems(Q);
  int m = dpq_nnodes(Q);
  double v = Q[i].v;
  int b = Q[i].b;

  while( i <= m/2 )
    {
    int j = 2*i;
    int k = j+1;
    if( k <= m )
      {
      if( 2*k <= n )
        {
        if( Q[k].v >= Q[j].v ) j = k;
        }
      else
        {
        if( Q[k].u >= Q[j].v ) j = k;
        }
      }

    if( 2*j <= n )
      {
      if( v >= Q[j].v )
        { Q[i].v = v; Q[i].b = b; return; };
      Q[i].v = Q[j].v; Q[i].b = Q[j].b;
      if( v < Q[j].u )
        {
        double t = Q[j].u; int c = Q[j].a;
        Q[j].u = v; Q[j].a = b;
        v = t; b = c;
        }
      Q[j].v = v; Q[j].b = b;
      }
    else // singleton
      {
      if( v > Q[j].u )
        { Q[i].v = v; Q[i].b = b; return; }
      Q[i].v = Q[j].u; Q[i].b = Q[j].a;
      Q[j].u = v; Q[j].a = b;
      }
    i = j;
    }
}

int  // return -1 if queue full, else return the new length
dpq_insert ( dpq_t *Q, double x, int c )
{
  if( Q[0].a == 2*Q[0].b ) return -1;
  int n = ++(Q[0].a);
  int i = (n+1)/2;
  int p = i/2;
  if( 0x1 & n ) // odd
    {
    if( x < Q[p].u ) 
      {
      Q[i].u = x; Q[i].a = c;
      dpq_up_L ( Q, i );
      }
    else if( x > Q[p].v )
      {
      Q[i].u = Q[p].v; Q[i].a = Q[p].b;
      Q[p].v = x; Q[p].b = c;
      dpq_up_R( Q, p );
      }
    else
      {
      Q[i].u = x; Q[i].a = c;
      }
    }
  else // even
    {
    if( x < Q[i].u )
      {
      Q[i].v = Q[i].u; Q[i].b = Q[i].a;
      Q[i].u = x; Q[i].a = c;
      dpq_up_L ( Q, i );
      }
    else
      {
      Q[i].v = x; Q[i].b = c;
      dpq_up_R ( Q, i );
      }
    }
  return n;
}


// if the new item is smaller than the maximum, use it to replace the max
int
dpq_pushmin ( dpq_t *Q, double x, int c )
{
  if( x < Q[1].v )
    {
    if( x < Q[1].u )
      {
      Q[1].v = Q[1].u; Q[1].b = Q[1].a; 
      Q[1].u = x; Q[1].a = c;
      }
    else
      {
      Q[1].v = x; Q[1].b = c;
      }
    
    dpq_down_R ( Q, 1 );
    return Q[0].a;
    }
  else
    return -1;
}

// if the new item is larger than the minimum, use it to replace the min
int
dpq_pushmax ( dpq_t *Q, double x, int c )
{
  if( x > Q[1].u )
    {
    if( x > Q[1].v )
      {
      Q[1].u = Q[1].v; Q[1].a = Q[1].b; 
      Q[1].v = x; Q[1].b = c;
      }
    else
      {
      Q[1].u = x; Q[1].a = c;
      }
    dpq_down_L ( Q, 1 );
    return Q[0].a;
    }
  else
    return -1;
}

void
dpq_search ( dpq_t *Q, double x, int c,
  int *node_, // pointer to the node 
  int *which_ // 0: left (min), 1: right (max)
  )
{
  int nitems = dpq_nitems(Q);
  int nnodes = dpq_nnodes(Q);
  *node_ = 0;          // not found
  *which_ = -1;

  for(int i = 1; i <= nnodes ; )
    {
    int singleton = (2*i > nitems );
    
    // check for match
    //
    if( Q[i].u == x && Q[i].a == c )
      { *node_ = i; *which_ = 0; break; }
    if( !singleton && Q[i].v == x && Q[i].b == c )
      { *node_ = i; *which_ = 1; break; }

    // if the interval contain the key, visit children (if they exist)
    if( !singleton && x >= Q[i].u && x <= Q[i].v ) 
      {
      int j = 2*i;
      if( j <= nnodes )
        { i = j; continue; }
      }

    // try moving to the right
    int j = i + 1; 
    
    if( 0x1 & j ) // on the right branch
      {
      if( j <= nnodes )
        { i = j; continue; }
      else                    // node doesn't exist, therefore
        { j /= 2; j++; }      // back up and then go on to the uncle
      }
    
    // retract to the uppermost ancestor not yet visited
    while( (0x1 & j) == 0 )
      j /= 2;

    if( j == 1 ) break; // rightmost node
    i = j;
    }
}

void
dpq_delete_L (dpq_t *Q, int node )
{
  int n = dpq_nitems(Q);
  if( n <= 0 || 2*node - 1 > n ) 
    return;
  if( 2*node - 1 == n ) // last item on the heap
    { Q[0].a--; return; }

  int m = dpq_nnodes(Q);
  double w; int c;
  if( 2*m > n ) // last is a singleton
    {
    w = Q[m].u;
    c = Q[m].a;
    }
  else
    {
    w = Q[m].v;
    c = Q[m].b;
    }
  Q[0].a--;

  if( w <= Q[node].v )
    {
    Q[node].u = w;
    Q[node].a = c;
    dpq_up_L( Q, node );
    dpq_down_L( Q, node );
    }
  else
    {
    Q[node].u = Q[node].v; Q[node].v = w;
    Q[node].a = Q[node].b; Q[node].b = c;
    dpq_up_R( Q, node );
    dpq_down_L( Q, node );
    }
}

void
dpq_delete_R (dpq_t *Q, int node )
{
  int n = dpq_nitems(Q);
  if( n <= 0 || 2*node - 1 > n ) 
    return;
  if( 2*node - 1 == n ) // last item on the heap
    { Q[0].a--; return; }

  int m = dpq_nnodes(Q);
  double w; int c;
  if( 2*m > n ) // last is a singleton
    {
    w = Q[m].u;
    c = Q[m].a;
    }
  else
    {
    w = Q[m].v;
    c = Q[m].b;
    }
  Q[0].a--;

  if( w >= Q[node].u )
    {
    Q[node].v = w;
    Q[node].b = c;
    dpq_up_R( Q, node );
    dpq_down_R( Q, node );
    }
  else
    {
    Q[node].v = Q[node].u; Q[node].u = w;
    Q[node].b = Q[node].a; Q[node].a = c;
    dpq_up_L( Q, node );
    dpq_down_R( Q, node );
    }
}

int
checkheap( dpq_t *Q, char *msg )
{
  int n = dpq_nitems(Q);
  int m = dpq_nnodes(Q);
  int what = 0;
  if( n > 1 && Q[1].u > Q[1].v )
    { what = 1; return 1; }
  int j = 2; int where = 0;
  for(; j <= m; j++ )
    {
    int i = j/2;
    if( Q[j].u < Q[i].u ) { where = j; what = 2; break; }
    if( 2*j <= n ) 
      {
      if( Q[j].u > Q[j].v ) { where = j; what = 1; break; }
      if( Q[j].v > Q[i].v ) { where = j; what = 3; break; }
      }
    else
      if( Q[j].u > Q[i].v ) { where = j; what = 3; break; }
    }

  if( where > 0 )
    {
    fprintf(stderr,"%s: corrupt heap at %d, type %d\n", msg ? msg : "", where, what );
    int i = 1;
    for(; i < m; i++ )
      fprintf(stderr,"%3d: [%g @ %d, %g @ %d]\n", i, Q[i].u,Q[i].a,Q[i].v,Q[i].b);
    if( n & 0x1 )
      fprintf(stderr,"%3d: [%g @ %d, ]\n", i, Q[i].u,Q[i].a);
    else
      fprintf(stderr,"%3d:: [%g @ %d, %g @ %d]\n", i, Q[i].u,Q[i].a,Q[i].v,Q[i].b);

    exit(0);
    }
  return where;
}

int
dpq_remove( dpq_t *Q, double value, int id, int *which_ )
{
  int node, which;
  dpq_search( Q, value, id, &node, &which );
  if( node > 0 )
    {
    if( which == 0 )
      dpq_delete_L( Q, node );
    else
      dpq_delete_R( Q, node );
    }
  if( which_ ) *which_ = which;
  return node;
}

int dpq_relabel( dpq_t *Q, double value, int id, int new_id, int *which_ )
{
  int node, which;
  dpq_search( Q, value, id, &node, &which );
  if( node > 0 )
    {
    if( which == 0 )
      Q[node].a = new_id;
    else
      Q[node].b = new_id;
    }
  if( which_ ) *which_ = which;
  return node;
}
