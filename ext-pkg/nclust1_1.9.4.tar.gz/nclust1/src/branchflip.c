/*
 * branchflip.c - branch reordering of hierarchical clusters
 *
 */

#include "branchflip.h"

#include <stdio.h>

int
nearest_nephew ( mergetree_t *T, 
    BRFLIP_MERGE_FUNC merge,
    BRFLIP_DISS_FUNC diss, 
    BRFLIP_FREE_FUNC brfree,
    void *context )
{
  int N = T[0].left;
  int *stack = (int*)malloc(sizeof(int)*N);
  struct branches { int L, R, M; };
  struct branches *L = (struct branches*)malloc(sizeof(*L)*N);
  struct branches *R = (struct branches*)malloc(sizeof(*R)*N);
  int *flipbit = (int*)malloc(sizeof(int)*N);
  int status = 0;

  R[0].L = R[0].R = R[0].M = -1; // to avoid brfree() crashing if N <= 4

  stack[0] = 0; T[0].right = N-1;  // use the dummy node as a sentinel
  int p = 1;
  stack[p] = N-1;
  int prev = 0;
  while( p > 0 )
    {
    int i = stack[p];
    if( i > 0 )
      {
      if( prev == T[i].left ) // return from the left child
        {
        stack[++p] = T[i].right;
        }
      else if( prev == T[i].right ) // return from the right child
        {
        // set the flip bits on non-terminal child branches.
        // flipbit = 1, flip the branch in the next tree traversal
        //
        if( T[i].left > 0 )
          {
          flipbit[T[i].left] = 
            (diss(L[i].L, R[i].M, context) < diss(L[i].R, R[i].M, context));
          brfree( L[i].L, context );
          brfree( L[i].R, context );
          }
        
        if( T[i].right > 0 )
          {
          flipbit[T[i].right] = 
            (diss(R[i].L, L[i].M, context) > diss(R[i].R, L[i].M, context));
          brfree( R[i].L, context );
          brfree( R[i].R, context );
          }
          
        // assign id's of branch summary in the parent's record
        int j = stack[p-1]; // parent
        if( i == T[j].left ) // left node
          {
          L[j].L = L[i].M; L[j].R = R[i].M;
          L[j].M = merge( L[i].M, R[i].M, context );
          }
        else // right node
          {
          R[j].L = L[i].M; R[j].R = R[i].M;
          R[j].M = merge( L[i].M, R[i].M, context );
          }

        p--;
        }
      else // enter from parent
        {
        if( p > N - 2 ) { status = 2; break; }   // corrupt tree: overflow
        stack[++p] = T[i].left;
        }
      }
    else // i is a terminal node
      {
      int j = stack[p-1]; // parent
      if( i == T[j].left ) // i is the left node
        { 
        L[j].L = L[j].R = 0;
        L[j].M = merge( i, 0, context );
        }
      else // i is the right node
        {
        R[j].L = R[j].R = 0;
        R[j].M = merge( i, 0, context );
        }
      p--;
      }
    prev = i;
    }
  brfree( R[0].L, context );
  brfree( R[0].M, context );
  brfree( R[0].R, context );

  //
  // flip each branch according to the flip bits
  //
  flipbit[N-1] = 0;       // use existing root-level branch order
  p = 0;
  stack[p] = N-1;
  int *flipstack = (int*)L;
  flipstack[0] = 0;
  while ( p >= 0 )
    {
    int i = stack[p];
    
    int i_just_flip = 0;
    if( flipstack[p] ^ flipbit[i] )
      {
      int t = T[i].left; T[i].left = T[i].right; T[i].right = t;
      i_just_flip = 1;
      }
    p--; // we won't return. pre-order traversal is good enough here
      
    if( T[i].right > 0 )
      {
      stack[++p] = T[i].right;
      flipstack[p] = i_just_flip;
      }
    if( T[i].left > 0 )
      {
      stack[++p] = T[i].left;
      flipstack[p] = i_just_flip;
      }
    }
  
  free(L); free(R);
  free(stack);
  free(flipbit);
  return status;
}
