#include <stdlib.h> // malloc, free
#include <stdio.h> // debugging only
#include <math.h> // INFINITY

/*
Output points that can be plotted as a tree using 'lines()' in R

The ouput is N + 3(N-1) coordinates. Internal node needs to be
visited three times to allow the whole tree to be treated as
an unbroken polygon.

branchtype:
  0 use straigth edge
  1 use 90-degree angled edge
*/
void
R_dendrolines (
  int *n_, int* merge, double *height, double *hang_,
  int *branchtype_,
  double *x, double *y  ) // output, should be allocated for N + 3(N-1) points
{
  int N = *n_;
  int branchtype = *branchtype_;
  double minheight = INFINITY, maxheight = -INFINITY;
  for(int i = 0; i < N-1; i++ )
    {
    if( height[i] < minheight ) minheight = height[i];
    if( height[i] > maxheight ) maxheight = height[i];
    }
  double hang = *hang_ * (maxheight-minheight);
  double bottom = 0;
  if( hang < 0 )
    bottom = minheight + hang;
  
  int *left = merge - 1;
  int *right = left + N-1;
  double *linkscore = height - 1;
  typedef struct { int i; int j1, j2; } stack_t;
  stack_t *stack = (stack_t*)malloc(sizeof(stack_t)*N);
  
  int p = 0;
  stack[p].i = N-1;
  int prev = 0;
  double xc = 1.0; // current node position
  double xbr = 0;
  int j = 0;   // index to the point
  while( p >= 0 )
    {
    int i = stack[p].i;
    if( i > 0 ) // i is an internal node
      {
      if( left[i] == prev ) // return from left child
        {
        if( branchtype == 1)
          {
          int k = stack[p].j1 + 1; // left shoulder, first visit
          x[j] = x[k] = xbr;
          y[j] = y[k] = linkscore[i];
          j++;
          }
        x[j] = xbr; // store for future recalculation of the mean 
        stack[p].j2 = j;
        stack[++p].i = right[i];
        if( branchtype == 1)
          j++;                // reserve right shoulder
        }
      else if ( right[i] == prev ) // return from right child 
        {
        if( branchtype == 1 )
          {
          int k = stack[p].j2 + 1;  // right shoulder first visit
          x[j] = x[k] = xbr;
          y[j] = y[k] = linkscore[i];
          j++;
          }

        // the neck is the mean of left and right 
        xbr = 0.5*(x[stack[p].j2] + xbr);
        x[j] = xbr;
        y[j] = linkscore[i];
        x[stack[p].j1] = x[stack[p].j2] = x[j];
        y[stack[p].j1] = y[stack[p].j2] = y[j];
        p--;
        }
      else // enter from the parent
        {
        stack[p].j1 = j;
        if(branchtype == 1)
          j++;                  // reserve left shoulder
        stack[++p].i = left[i];
        }
      }
    else // i is terminal node
      {
      x[j] = xc;
      xbr = xc;
      xc++;
      if(hang >= 0 )
        y[j] = linkscore[stack[p-1].i] - hang;
      else
        y[j] = bottom;
      p--;
      }
    prev = i;
    j++;
    }
  free(stack);
}
