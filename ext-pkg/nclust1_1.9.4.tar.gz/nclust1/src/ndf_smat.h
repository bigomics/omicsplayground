/*
 * ndf_smat.h - sparse matrix data
 */
#ifndef _SMAT_NCLUST_H_
#define _SMAT_NCLUST_H_

#include "mergetree.h"

void
smat_nclust(
  int m,          // number of pairs
  const int *level1, const int *level2, // m-vector of 'levels'
  double *x,      // (optional) m non-zero values
  int distance,   // 0: 1-cosine, TODO: 1, 1-Jaccard

  // output
  int link,       // link function
  mergetree_t *T
  );
#endif //  _SMAT_NCLUST_H_
