/*
 * dendropart.c - select a subset of dendrogram
 *
 */

#include <stdlib.h>
#include <stdio.h>

#include "mergetree.h"

void
R_dendropart (
  int *n_, int *merge,
  int *subset, // subset definition: 1 include, 0 discard
  int *m_,  // size of output, already known (number of leaf minus one)
  // output
  int *submerge,  // a merge structure, with new branch id
  int *subbranch  // reference to old branch indices
  )
{
  int N = *n_, M = *m_;
  for(int j = 0; j < N-1; j++ )
    for(int i = j; i < 2*(N-1); i += N-1 )
      if( merge[i] < 0 )
        {
        if( subset[-merge[i]-1] == 0 )
          merge[i] = 0;
        }
      else if(merge[i] > 0 )
        {
        int k = merge[i]-1;
        if( merge[k] == 0 )
          {
          if( merge[k+N-1] == 0 )
            merge[i] = 0;
          else
            {
            merge[i] = merge[k+N-1];
            merge[k+N-1] = 0;
            }
          }
        else // merge[k] != 0
          {
          if( merge[k+N-1] == 0 )
            {
            merge[i] = merge[k];
            merge[k] = 0;
            }
          }
        }

  // copy
  int u = 0;
  for(int j = 0; j < N-1; j++ )
    if( merge[j] != 0 )
      {
      submerge[u] = merge[j];
      submerge[u+M-1] = merge[j+N-1]; 
      subbranch[u] = j+1;
      // subheight[u] = height[j];
      merge[j] = u+1;
      if(submerge[u] > 0)
        submerge[u] = merge[submerge[u]-1];
      if(submerge[u+M-1] > 0)
        submerge[u+M-1] = merge[submerge[u+M-1]-1];
      u++;
      }
}
