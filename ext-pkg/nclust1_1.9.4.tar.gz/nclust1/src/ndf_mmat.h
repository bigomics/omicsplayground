/*
 * ndf_mmat.h - multiple matrix co-clustering
 *
 */

#ifndef _MMAT_NCLUST_H_
#define _MMAT_NCLUST_H_

#include "nclust.h"
#include "branchflip.h"

typedef struct {
  int n;
  int *i;
  }
  ivec;

typedef struct {
  double z; double w; // zcorr and its inverse variance (df-3)
  }
  zmat_t;

typedef struct {
  int K;
  int *nrow;
  int *coff; // column offset
  int *doff; // data offset
  int nu;  // number of union of columns
  int *idx;  // column indices (K x nu )
  double *data;
  ivec **nainfo;
  int diss; // 0: nzcor rema, 1: nzcor fema
  zmat_t *zmat; // K * nu
  
  double *pwdist; // pairwise distance
  }
mmat_t;

#define MAXCORR .999999

// R interface

extern void
R_mmat_nclust ( 
  // input
  int *K_, int *nrow, int *ncol,
  int *n_unicol_, int *idx,   // union of cols, and its index
  double *data,
  
  // TODO: input study-level covariates (e.g. hierarchical stratification)

  // options
  int *disscode_,
  int *linkcode_,
  int *bflipcode_,

  // output
  double *s2, int *df, // total variance and df of the columns

  int *merge,
  double *linkscore,
  int *order,
  int *leaf_level,
  int *branch_level,
  int *n_leaf,
  int *sum_level,
  double *sumsq_level,
  int *bounds,
  int *n_leaf_parent,

  int *savepwdist_,
  double *pwdist  // pairwise distance matrix
  );

#endif // _MMAT_NCLUST_H_
