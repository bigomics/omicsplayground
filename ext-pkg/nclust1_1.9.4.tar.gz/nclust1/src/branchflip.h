/*
  branchflip.h
*/
#ifndef _BRANCHFLIP_H_
#define _BRANCHFLIP_H_

#include "mergetree.h"

/*
 callback functions

 nearest_nephew() will send the node id's (in 'mergetree' convention)
 to the callbacks. 
*/ 

/*
create new branch:
  - if b is zero and a is negative: consider a as a new branch
  - if a and b is negative: two terminal nodes
*/
typedef int (*BRFLIP_MERGE_FUNC) (
  int a, int b, 
  void *context     
  );

typedef double (*BRFLIP_DISS_FUNC) (
  int a, int b,     // id's of branch to be compared
  void *context
  );

// discard unused branch
typedef void (*BRFLIP_FREE_FUNC) (
  int a, void *context
  );

extern int
nearest_nephew ( mergetree_t *T, 
    BRFLIP_MERGE_FUNC merge,
    BRFLIP_DISS_FUNC diss, 
    BRFLIP_FREE_FUNC brfree,
    void *context );

#endif /* _BRANCHFLIP_H_ */
