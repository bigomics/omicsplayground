#include <stdlib.h>
/*
Segment time series data into 
  0 increasing
  1 flat
  2 decreasing
*/
void
segment3 ( int n, int *y, double smalljump, double bigjump, int *x )
{
  char *p = (char*) malloc(sizeof(char)*n*3);
  double Sdown_prev, Sdown, Sflat_prev, Sflat, Sup_prev, Sup;

  Sdown_prev = Sflat_prev = Sup_prev = 0;
  Sup = Sflat = Sdown = 0;

  p[0] = p[1] = p[2] = x[0] = -1;

  // forward accumulation
  for(int i = 1; i < n; i++ )
    {
    //int d = (y[i] > y[i-1] ? 1: (y[i] < y[i-1] ? -1: 0));
    double d = y[i]-y[i-1];
    double f;
  
    Sdown = Sdown_prev - d;
    p[i*3 + 0] = 0;
    f = Sflat_prev - smalljump;
    if( f > Sdown )
      { Sdown = f; p[i*3 + 0] = 1; }
    f = Sup_prev + d - bigjump;
    if( f > Sdown )
      { Sdown = f; p[i*3 + 0] = 2; }
    
    Sflat = Sdown_prev - d - smalljump;
    p[i*3 + 1] = 0;
    f = Sflat_prev;
    if( f > Sflat )
      { Sflat = f; p[i*3 + 1] = 1; }
    f = Sup_prev + d - smalljump;
    if( f > Sflat )
      { Sflat = f; p[i*3 + 1] = 2; }
    
    Sup = Sdown_prev - d - bigjump;
    p[i*3 + 2] = 0;
    f = Sflat_prev - smalljump;
    if( f > Sup )
      { Sup = f; p[i*3 + 2] = 1; }
    f = Sup_prev + d;
    if( f > Sup )
      { Sup = f; p[i*3 + 2] = 2; }
    
    Sdown_prev = Sdown;
    Sflat_prev = Sflat;
    Sup_prev = Sup; 
    }
  
  // backtrack
  int j = 0;
  if( Sflat_prev > Sdown_prev )
    j = 1;
  if( j == 0 && Sup_prev > Sdown_prev )
    j = 2;
  if( j == 1 && Sup_prev > Sflat_prev )
    j = 2;

  for(int i  = n-1; i > 0; i-- )
    {
    x[i] = j;
    j = p[i*3+j];
    }
  free(p);
}

void
R_findpeak ( int *n_, int *leaf_level,
  double *smalljump_, double *bigjump_, int *segment,
  int *npeaks_, int *peaks, int *ntroughs_, int *troughs  )
{
  segment3 ( *n_, leaf_level, *smalljump_, *bigjump_, segment );
  int npeaks = 0, ntroughs = 0;
  for(int i = 2; i < *n_; i++ )
    if( segment[i] == 0 && segment[i-1] == 2 )
      peaks[npeaks++] = i+2;
    else if ( segment[i] == 2 && segment[i-1] == 0 )
      troughs[ntroughs++] = i+2;
  *npeaks_ = npeaks;
  *ntroughs_ = ntroughs;
}
