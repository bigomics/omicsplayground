/*
nclust.c - nearest-neighbor chain for hierarchical clustering

*/

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <math.h>

#include "nclust.h"
#include "dpq.h"        // for double-ended priority queue data structure

#define QLENGTH 30      // number of nearest neighbors to keep in queue

struct nclust {
  
  /* input data */
  int N;          // number of leaf nodes
  
  NCLUST_DISS_FUNC dfunc; // distant function
  void *context;
  enum link_t link;

  /* internal states */
  int next_cluster; // next available cluster identifier 

  struct slot_t {
    int cluster;     // cluster identifiers
    int n_leaf;
    int chainpos; // position in the chain (-1 if not in the chain)
    int cachepos; // position in 'cached_slot', for efficient deletion
    struct cache_t { 
      int size;                // for memory benchmark
      dpq_t Q[(QLENGTH/2)+1];  // nearest neighbors queue
      double D[];              // distance to other clusters
      } *cache; 
    } *slot;
  int n_slot; // number of currently 'active' slots

  int *cached_slot; // list of slots with cache
  int n_cached;     // the length of the list 

  int *chain;
  int q; // pointer to the end of the chain

  int *B; // list of leaf id's for callback
  int *J; // list of slot id (for return values filled by callback)

  /* performance stat */
  int maxchain;
  int maxcache;
  int mem;
  int maxmem;

  int count_nearest;  // how often nearest() is called
  int count_cache_hit; // how often it is already cached
  int count_queue_refill;// how often calling nearest causes refill

  /* output */
  mergetree_t *mergetree;
};

static void
nclust_free (struct nclust* C)
{
  if(C->slot)
    {
    for(int i = 0; i < C->n_slot; i++ )
      if( C->slot[i].cache )
        free( C->slot[i].cache );
    free(C->slot);
    }
  if(C->cached_slot)
    free(C->cached_slot);
  free(C);
  
  return;
}

static struct nclust*
nclust_init ( int N,
  NCLUST_DISS_FUNC dfunc, void *context,
  enum link_t link,
  mergetree_t *mergetree )
{
  struct nclust *C = (struct nclust*)malloc(sizeof(*C));
  if( !C )
    return NULL;
  
  C->N = N;
  C->dfunc = dfunc;
  C->context = context;
  C->link = link;

  C->next_cluster = 1;  // index to next available mergetree record
  
  C->slot = (struct slot_t*)malloc( sizeof(*C->slot) * N );
  if(!C->slot)
    { nclust_free(C); return NULL; }
  
  // init slots 
  for(int i = 0; i < N; i++ )
    {
    C->slot[i].cluster = -(i+1);  // label terminal nodes as -1,..,-N
    C->slot[i].n_leaf = 1;
    C->slot[i].chainpos = -1;
    C->slot[i].cachepos = -1;
    C->slot[i].cache = NULL;
    }
  C->n_slot = N;

  C->n_cached = 0;
  C->cached_slot = (int*)malloc(sizeof(int)*N*4);
  if(!C->slot)
    { nclust_free(C); return NULL; }
  C->chain = C->cached_slot + N;
  C->B = C->chain + N;
  C->J = C->B + N;

  C->maxchain = 0;
  C->maxcache = 0;
  C->mem = sizeof(*C) + sizeof(*C->slot) * N + sizeof(int)*N*4 ;
  C->maxmem = C->mem;
  
  C->count_nearest = 0;
  C->count_queue_refill = 0;
  C->count_cache_hit = 0;

  C->mergetree = mergetree;

  return C;
}

static void
nclust_refill_queue( struct nclust* C, int i )
{
  
  double *D = C->slot[i].cache->D;
  dpq_t *Q = C->slot[i].cache->Q;

  Q[0].a = 0; // empty it (maybe superfluous)
  for(int j = 0; j < C->n_slot; j++ )
    {
    if( j == i || !isfinite(D[j]) ) continue;
    dpq_insertmin( Q, D[j], j );
    }
}

static int
nclust_nearest( struct nclust *C, int i, int *in_chain )
{
  struct slot_t *si = & C->slot[i];
  C->count_nearest++;
  if( si->cache )
    {
    C->count_cache_hit++;
    if( si->cache->Q[0].a == 0 )
      {
      C->count_queue_refill++;
      nclust_refill_queue ( C, i );
      }
    }
  else // has to be a terminal node
    {
    // create a new cache
    int csize = sizeof(struct cache_t) + sizeof(double)*(C->n_slot);
    si->cache = (struct cache_t*)malloc( csize );
    if( ! si->cache ) 
      {
      fprintf(stderr,"can't allocate for slot %d\n", i);
      return -1;
      }
    si->cache->size = csize;
    C->mem += csize;
    if( C->mem > C->maxmem ) C->maxmem = C->mem;
    dpq_init( si->cache->Q );
    si->cache->Q[0].b = QLENGTH/2;

    si->cachepos = C->n_cached;
    C->cached_slot[(C->n_cached)++] = i;
    
    // fill the score
    double *D = C->slot[i].cache->D;
    int nreq = 0; // number of requested pairs for callback
    int a = - C->slot[i].cluster - 1; // convert -1..-N to 0..N-1
    for(int j = 0; j < C->n_slot; j++ )
      {
      if( j == i )
        D[j] = INFINITY; // exclude from min queue
      else if(C->slot[j].cache) 
        D[j] = C->slot[j].cache->D[i];
      else
        {
        C->B[nreq] = -C->slot[j].cluster - 1; // convert -1..-N to 0..N-1
        C->J[nreq] = j;
        nreq++;
        }
      }
    if( nreq > 0 )
      (C->dfunc)(a, nreq, C->B, C->J, D, C->context );

    // fill the queue
    nclust_refill_queue ( C, i );
    }

  int j = dpq_imin( si->cache->Q );
  *in_chain =  (C->slot[j].chainpos >= 0 ? 1: 0);
  return j;
}

static void
nclust_merge ( struct nclust* C, int a, int b )
{
  int i, j;

  // Ensure i < j
  if( a < b )
    { i = a; j = b; }
  else
    { i = b; j = a; }

  if(C->maxchain < C->q) C->maxchain = C->q;
  if(C->maxcache < C->n_cached) C->maxcache = C->n_cached;
      
  struct slot_t *slot = C->slot;
  
  int new_cluster = (C->next_cluster)++;

  // Add a new cluster of merged i and j to the mergetree output.
  // Use the 'tight left' branch-ordering rule
  if( C->mergetree)
    {
    int l = slot[i].cluster, r = slot[j].cluster;
    if( l < 0 && r < 0 )
      {
      if( l < r )
        { int t = l; l = r; r = t; }
      }
    else
      {
      double ll = l < 0 ? -INFINITY : C->mergetree[l].height;
      double lr = r < 0 ? -INFINITY : C->mergetree[r].height;
      if( ll > lr )
        { int t = l; l = r; r = t; }
      }
    C->mergetree[new_cluster].left = l;
    C->mergetree[new_cluster].right = r;
    C->mergetree[new_cluster].height = slot[i].cache->D[j];
    }
  
  if(C->n_slot == 2)
    return;

  C->q -= 2; // pop merged elements from the chain

  // Overwrite slot i by the new cluster
  int Ni = slot[i].n_leaf,
      Nj = slot[j].n_leaf;
  
  slot[i].cluster = new_cluster;
  slot[i].n_leaf = Ni + Nj;
  slot[i].chainpos = -1;    // remove from the chain

  // Lance-Williams update of the score cache for cluster i <- merge(i,j) 
  int Nij = Ni + Nj;
  double *Di = slot[i].cache->D, *Dj = slot[j].cache->D;
  switch( C->link)
    {
    case AVERAGE:
      for(int k = 0; k < C->n_slot; k++ )
        Di[k] = (Ni * Di[k] + Nj * Dj[k])/Nij;
      break;
    case MCQUITTY:
      for(int k = 0; k < C->n_slot; k++ )
        Di[k] = 0.5 * (Di[k] + Dj[k]);
      break;
    case WARD_L:
      {
      double Dij = slot[i].cache->D[j];
      for(int k = 0; k < C->n_slot; k++ )
        {
        int Nk = slot[k].n_leaf;
        Di[k] = ((Ni+Nk)*Di[k] + (Nj+Nk)*Dj[k] - Nk*Dij)/(Nij+Nk);
        }
      }
      break;
    case SINGLE:
      for(int k = 0; k < C->n_slot; k++ )
        Di[k] = (Di[k] < Dj[k] ? Di[k] : Dj[k] );
      break;
    case COMPLETE:
      for(int k = 0; k < C->n_slot; k++ )
        Di[k] = (Di[k] > Dj[k] ? Di[k] : Dj[k] );
      break;
    case ALLPAIR:
      {
      double Dij = slot[i].cache->D[j];

      for(int k = 0; k < C->n_slot; k++ )
        {
        int Nk = slot[k].n_leaf;
        fprintf(stderr,"%d: %g %g\n",k,Di[i],Dj[j]);
      /*
        Di[k] = ((Ni+Nk) * Di[k] + (Nj+Nk)*Dj[k] + Nij*Dij)
                - Ni*Di[i] - Nj*Dj[j] - Nk*Dkk )/(Nij + Nk);
      */
        }
      for(int k = 0; k < C->n_slot; k++ )
        Di[k] = (Ni * Di[k] + Nj * Dj[k])/Nij;
      }
      break;
    }
  Di[i] = Di[j] = INFINITY; // exclude from min queue

  C->n_slot--;
  
  // Delete j
  C->mem -= slot[j].cache->size;
  free(slot[j].cache);
  slot[j].cache = 0;    // help debugging
  slot[j].chainpos = -1;
  
  // Remove j from cached list
  (C->n_cached)--;
  int u = slot[j].cachepos;
  if( u < C->n_cached )
    {
    C->cached_slot[u] = C->cached_slot[C->n_cached];
    slot[C->cached_slot[u]].cachepos = u;
    }
  
  int m = C->n_slot;
  if( j != m )  // change references from m to j
    {
    
    slot[j].cluster = slot[m].cluster;
    slot[j].n_leaf = slot[m].n_leaf;
    
    slot[j].cache = slot[m].cache;
    slot[j].cachepos = slot[m].cachepos;
    if(slot[m].cachepos >= 0 )
      C->cached_slot[slot[m].cachepos] = j;
  
    slot[j].chainpos = slot[m].chainpos;
    if(slot[j].chainpos >= 0 )
      C->chain[slot[j].chainpos] = j;

    }
  
  // Update cache for i
  Di[j] = Di[m];
  nclust_refill_queue ( C, i );

  // Update each cached slot: insert new i, replace j by m
  for(u = 0; u < C->n_cached; u++ )
    {
    int v = C->cached_slot[u];
    if( v == i ) 
      continue;
    

    double *D = C->slot[v].cache->D;
    dpq_t *Q = C->slot[v].cache->Q;

    
    // Remove old i
    dpq_remove( Q, D[i], i, NULL );

    // Insert new i
    D[i] = Di[v];
    if( isfinite(D[i]) )
      dpq_pushmin ( Q, D[i], i );  

    // Remove j from Q
    dpq_remove( Q, D[j], j, NULL );

    // Replace reference to m by reference to j
    if( j < m )
      {
      D[j] = D[m];
      dpq_relabel ( Q, D[m], m, j, NULL );
      }
    } // for each cached slot
 
}

static void
nclust_extend_chain(struct nclust* C, int i)
{
  C->q++;
  C->chain[C->q] = i;
  C->slot[i].chainpos = C->q;
}

int
nclust ( int N, 
  NCLUST_DISS_FUNC dfunc, void *context,
  enum link_t link,
  mergetree_t *mergetree       // 2 x N, left branch is the first row
  )
{
  if( link > ALLPAIR )
    return 4;
  if( N < 2 ) 
    return 3; 
  
  struct nclust* C = nclust_init ( N, dfunc, context, link, mergetree );
  if( C == NULL )
    {
    fprintf(stderr,"nclust_init() can't allocate memory.\n");
    return 1;
    }
  
  int *chain = C->chain;
  
  C->q = -1;
  while( C->n_slot > 2 )
    {
    int i, in_chain;
    i = (C->n_cached ? C->cached_slot[0] : 0); // start chain
    nclust_extend_chain( C, i );
    i = nclust_nearest( C, chain[(C->q)], &in_chain );
    if( i < 0 ) 
      { nclust_free(C); return 2; }
    nclust_extend_chain( C, i );
    do
      {
      i = nclust_nearest( C, chain[C->q], &in_chain );
      if( i < 0 )
        { nclust_free(C); return 2; }
      if( in_chain )
        nclust_merge ( C, chain[C->q], chain[C->q - 1] );
      else
        nclust_extend_chain( C, i );

      #if 0
      fprintf(stderr,"@%d: ",C->n_slot);
      for(int k = 0; k < C->q; k++ )
        fprintf(stderr,"%3d ",chain[k]);
      fprintf(stderr,"\n");
      #endif
      }
      while ( C->q >= 0 && C->n_slot > 2 );

    }
  nclust_merge ( C, 0, 1 );

  fprintf(stderr,"objects: %d\n", N );
  fprintf(stderr,"max memory: %d\n", C->maxmem );
  fprintf(stderr,"max chain : %d\n", C->maxchain );
  fprintf(stderr,"max cached : %d\n", C->maxcache );
  fprintf(stderr,"# cache hit: %d\n", C->count_cache_hit );
  fprintf(stderr,"# queue refill: %d\n", C->count_queue_refill );

  nclust_free(C);
  return 0;
}
