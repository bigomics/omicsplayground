/*
 * coldmap.c - cooler heatmap
 */
#include <stdlib.h>
#include <math.h>

#include <stdio.h>

// Downsample a matrix by averaging non-overlapping blocks of size w1 x w2
// Centering and reordering are also performed.
void
R_downsample (
  const int *n1_, const int *n2_, const double *x, // input
  const int *w1_, const int *w2_, // averaging windows
  const int *no1_, const int *no2_, // length of ord1 and ord2
  const int *ord1, const int *ord2,  // index ordering
  const int *center_,
  double *y, // output matrix
  double *mean_, double *sd_    // mean and sd of the output
  )
{
  int n1 = *n1_, n2 = *n2_;
  double *N1 = (double*)malloc(sizeof(double)*(2*n1+n2));
  double *s1 = N1 + n1;
  double *s2 = s1 + n1;
  for(int i = 0; i < 2*n1+n2; i++ )
    N1[i] = 0;
  
  const double *xi2 = x;
  for(int i2 = 0; i2 < n2; i2++, xi2 += n1 )
    {
    if(0x2 & *center_ )
      {
      double s12 = 0, N2 = 0;
      for(int i1 = 0; i1 < n1; i1++ )
        if(isfinite(xi2[i1]))
          {
          s12 += xi2[i1];
          N2++;
          }
      s2[i2] = s12/N2;
      }
    if(0x1 & *center_ )
      for(int i1 = 0; i1 < n1; i1++ )
        if(isfinite(xi2[i1]))
          {
          s1[i1] += xi2[i1] - s2[i2];
          N1[i1]++;
          }
    }
  if( 0x1 & *center_ )
    for(int i1 = 0; i1 < n1; i1++ )
      s1[i1] /= N1[i1];

  // copy-and-permute the margins
  int no1 = *no1_, no2 = *no2_;
  double *mu1 = (double*)malloc(sizeof(double)*(no1 + no2));
  double *mu2 = mu1 + no1;
  for(int k = 0; k < no1; k++ )
    mu1[k] = s1[ord1[k]];
  for(int k = 0; k < no2; k++ )
    mu2[k] = s2[ord2[k]];
  
  // reordering and downsampling
  int w1 = *w1_, w2 = *w2_;
  int m1 = (no1 + w1 - 1)/w1, m2 = (no2 + w2 - 1)/w2;
  int *Nj2 = (int*)malloc(sizeof(int)*m1);

  double *yj2 = y;
  double sy = 0, syy = 0, Ny = 0;
  for(int j2 = 0; j2 < m2; j2++, yj2 += m1 )
    {
    for(int j1 = 0; j1 < m1; j1++ )
      yj2[j1] = Nj2[j1] = 0;
    for(int i2 = j2*w2; i2 < j2*w2 + w2; i2++ )
      {
      if( i2 < 0 || i2 >= n2 ) continue;
      int oi2 = ord2[i2];
      if(oi2 < 0  ) continue;
      const double *xoi2 = x + oi2 * n1;
      for(int j1 = 0; j1 < m1; j1++ )
        {
        for(int i1 = j1*w1; i1 < j1*w1 + w1; i1++ )
          {
          if(i1 < 0 || i1 >= n1 ) continue;
          int oi1 = ord1[i1];
          if(oi1 < 0 || oi1 >= n1 ) continue;
          if(isfinite(xoi2[oi1]))
            {
            yj2[j1] += xoi2[oi1] - mu1[i1] - mu2[i2];
            Nj2[j1]++;
            }
          }
        }
      }
    for(int j1 = 0; j1 < m1; j1++ )
      {
      yj2[j1] /= Nj2[j1];
      if(isfinite(yj2[j1]))
        { 
        double v = yj2[j1];
        sy += v; syy += v*v;
        Ny++;
        }
      }
    }
  *mean_ = sy / Ny++;
  *sd_ = sqrt((syy - sy*sy/Ny)/(Ny-1));
  free(Nj2);
  free(mu1);
  free(N1);
}

// arrange placement of sparse labels to minimize overlap

void
R_labelpack (
  int *n_, const double *x,   // original positions, assume sorted already
  double *d_,                  // space taken by each, same unit as x
  double *minx_, double *maxx_, // boundary constraints on the output
  int *maxiter_,                // maximum iteration
  double *y                     // output
  )
{
  int n = *n_;
  if(n <= 0) return;

  double d = *d_;
  double minx = *minx_;
  double maxx = *maxx_;

  for(int i = 0; i < n; i++ )
    {
    y[i] = x[i];
    if(y[i] < minx ) y[i] = minx;
    if(y[i] > maxx ) y[i] = maxx;
    }
    
  int *g = (int*)malloc(sizeof(int)*(n+1));
  for(int i = 0; i <= n; i++ )
    g[i] = i;

  int collision = 0;
  for(int r = 0; r < *maxiter_; r++ )
    {
    collision = 0;
    for( int i = g[n-1]; i > 0; )
      {
      if( y[i] - y[i-1] <= d )
        {
        collision = 1;
        for(int j = i; g[j] == i; j++ )
          g[j] = g[i-1];
        }
      i = g[i-1];
      }
      
    if(!collision) break;
    
    /* adjust the location */
    for(int i = n-1; i > 0; i = g[i]-1 )
      {
      int nrun = i-g[i]+1;
      if(nrun == 1) continue;
      double mean_x = 0;
      for(int j = g[i]; j <= i; j++ )
        mean_x += y[j];
      mean_x /= nrun;
      double mean_j = 0.5*(g[i] + i);
      for(int j = g[i]; j <= i; j++ )
        y[j] = mean_x + (j-mean_j)*d;
        
      if(y[g[i]] < minx && y[i] > maxx )
        fprintf(stderr,"overcrowding\n");
        
      else if(y[g[i]] < minx )
        {
        double u = minx - y[g[i]] ;
        for(int j = g[i]; j <= i; j++ )
          y[j] += u;
        }
      else if( y[i] > maxx )
        {
        double u = y[i] - maxx;
        for(int j = g[i]; j <= i; j++ )
          y[j] -= u;
        }
      }
    }

  free(g);
  return;
}
