/*
nclust.h - nearest-neighbor chain for hierarchical clustering

The core algorithm, implemented in nclust(), can be applied
to data with arbitrary structures (pairwise distance,
matrix of features-vs-items, sparse matrix, etc.). The
only requirement is to have an appropriate callback function,
as defined by NCLUST_DISS_FUNC.

*/

#ifndef _NCLUST_H_
#define _NCLUST_H_


#include "mergetree.h"  // for the 'mergetree_t' to return the tree

/*
 * Callback function prototype to compute whole-sale
 * dissimilarity between leaf nodes, i.e. compute
 *
 * D[J[k]] = distant(a, B[k]),  for k = 0,..,nreq
 *
 *  [!] the distance can't be NAN, as this will cause nclust() to segfault
 */
typedef void
(*NCLUST_DISS_FUNC) (
  int a,           // index to the first node
  int nreq,        // number of comparison requested
  const int *B,    // list of indices to second nodes
  const int *J,    // list of indices to results (if NULL, same as B)
  double *D,       // results are put in D[J[i]]
  void *context    // context of the function (e.g. specific data)
  );

enum link_t {
  AVERAGE = 0,    // C3 in Gordon(1999) book
  MCQUITTY,       // C4
  WARD_L,         // C7
  SINGLE,         // C1
  COMPLETE,       // C2
  ALLPAIR         // C6 Sum-of-squares in Gordon(1999)
  };

/*
Perform hierarchical clustering using nearest-neighbor chain algorithm.

RETURN
  0: OK
  1: no memory (nclust_init)
  2: no memory (slot cache)
  3: N < 2
  4: invalid link 
*/
int
nclust ( 
  int N,                      // number of leaf nodes 
  NCLUST_DISS_FUNC dfunc,     // dissimilarity function 
  void *context,              // context/data for dissimilarity function
  enum link_t link,           // link function
  mergetree_t *mergetree      // output
  );

#endif /* _NCLUST_H_ */
