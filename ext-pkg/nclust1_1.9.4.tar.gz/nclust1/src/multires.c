/*
 * multires.c - multiresolution analysis of dendrogram depth profile
 *
 */

void
extreme_points ( int *n_, double *y, double *cutoff_, int *n_points_, 
  int *pos, double *value )
{
  int n = *n_;
  double cutoff = *cutoff_;
  int count = 0;
  int state = (y[0] <= cutoff ? -1: 1), i0 = 0, ix = 0;

  for(int i = 1; i < n; i++ )
    {
    if( state == -1 )
      {
      if( y[i] <= cutoff )
        {
        if( y[i] < y[ix] ) { ix = i; }
        }
      else
        {
        // if( *save_points_ ) { pos[count] = ix; value[count] = y[ix]; }
        if( pos ) pos[count] = ix;
        if( value ) value[count] = y[ix];
        count++;
        i0 = ix = i;
        state = 1;
        }
      }
    else
      {
      if( y[i] > cutoff )
        {
        if( y[i] > y[ix] ) { ix = i; }
        }
      else
        {
        // if( *save_points_ ) { pos[count] = ix; value[count] = y[ix]; }
        if( pos ) pos[count] = ix;
        if( value ) value[count] = y[ix];
        count++;
        i0 = ix = i;
        state = -1;
        }
      }
    }
  //if( *save_points_ ) { pos[count] = ix; value[count] = y[ix]; }
  if( pos ) pos[count] = ix;
  if( value ) value[count] = y[ix];
  count++;
  *n_points_ = count;
}

void
multires(
  int *n_,    // signal length
  double *y,  // 
  int *K_,    // number of levels
  double *Z   // high-freq filtered parts (k x n arrays)
  )
{
  int n = *n_, K = *K_;
  for(int k = 0; k < K; k++ )
    {
    int g = (1 << k );
    double *z = Z + k*n;
    for(int i = 0; i < n; i++ )
      {
      z[i] = 0.5 * y[i];
      z[i] -= 0.25 * (i-g >= 0 ? y[i-g] : y[0]);
      z[i] -= 0.25 * (i+g <  n ? y[i+g] : y[n-1]);
      }
    for(int i = 0; i < n; i++ )
      y[i] -= z[i];
    }
}

#if 0
void mr_peak_count ( int *n_, int *K_, double *z, int *count_ )
{
  int n = *n_, K = *K_;

  *count_ = 0;
  for(int k = 0; k < K; k++ )
    {
    int s = 0;
    int i0 = -1, ix = -1;
    for(int i = 0; i < n; i++ )
      {
      if( s > 0 )
        {
        if( z[i] > 0 )
          {
          if( z[i] > z[ix] ) 
            ix = i; 
          }
        else if (z [i] <= 0 )
          {
          for(int j = i0; j < i; j++ )
            if( j != ix ) z[j] = 0;  
          i0 = i; ix = i;
          s = (z[i] < 0 ? -1: 0);
          }
        }
      else if ( s < 0 ) 
        {
        if( z[i] < 0 )
          {
          if( z[i] < z[ix] ) 
            ix = i; 
          }
        else if (z [i] >= 0 )
          {
          for(int j = i0; j < i; j++ )
            if( j != ix ) z[j] = 0;  
          i0 = i; ix = i;
          s = (z[i] > 0 ? 1: 0);
          }
        }
      else // if  s == 0
        {
        if( z[i] > 0 ) { i0 = i; ix = i; s = 1; }
        else if( z[i] < 0) { i0 = i; ix = i; s = -1; }
        }
      }
    if( s != 0 )
      for(int j = i0; j < n; j++ )
        if( j != ix ) z[j] = 0;
  }
}
#endif
