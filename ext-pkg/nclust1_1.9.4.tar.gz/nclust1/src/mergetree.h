/*
 * mergetree.h - data structure for hierarchical clustering tree
 */

#ifndef _MERGETREE_H_
#define _MERGETREE_H_

#include <stdlib.h>

/*

The binary tree of hierarchical clusters with N nodes is represented
as an array of the 'mergetree_t' record defined below.

The first record is not used to represent a cluster. Instead, the 'left'
field contains the number of leaf nodes. The other fields are not used.

For the remaining N-1 records, 'left' and 'right' are array indices to
subclusters. If the index is negative, then it is an index to a leaf
node (singleton cluster), ranging from -1 to -N, the absolute value of
which corresponds to indices of the N clustered items.  If positive, it
is an index to the record (ranging from 1 to N-1).

'height' is the link score that correspons to the cluster.

*/ 
typedef struct {
  int left, right;
  double height;
} mergetree_t;

extern mergetree_t *alloc_mergetree(int N);

/*
Sort a merge tree according to the 'height', modify the cluster
indices accordingly. If U is not NULL, the sorted tree will be
written on U (T not modified). Otherwise, T will be modified.
*/
extern void
mergetree_sort ( mergetree_t *T, mergetree_t *U );

/*
Find various info about the nodes
 [!] items are indexed by 1..N (not the usual 0..N-1)
 [!] Assume the last record is the top cluster. This applies to
     output of 'nclust' although other clusters are not sorted by the height.

RETURN:
   0: OK, 1: too many leaf nodes 2: stack overflow 
*/

extern int
mergetree_node_info (
  // input
  mergetree_t *T,
  
  // output; can be NULL
  int *ordering,      // left-right ordering of the tree (indices to nodes)
  int *leaf_level,    // the level (depth) of the leaf nodes, use the same
                      // ordering as in 'ordering'
  int *branch_level,  // levels at internal nodes, the ordering is the
                      // as in T (but only N-1 items, without the dummy node).
                      // This is meant to be used as 'height'
  int *n_leaf,
  int *sum_level,
  double *sumsq_level,

  int *maxlevel_      // maximum level
  );

// save a tree to a file
extern void
mergetree_save ( mergetree_t *T, char *filename );

// load a tree from a file
extern mergetree_t *
mergetree_load ( char* filename );


/*
Convert mergetree_t to representation used by 'hclust' in R, as follows:

- The matrix 'merge' is of size (N-1) x 2, 
  The left branches are in 'merge[0..N-1]', the right branches are
  in 'merge[N..N-2]'
- 'height' is a separate (N-1) vector.

*/
static inline void
convert_to_Rformat ( mergetree_t *T, int *merge, double *height )
{
  int N = T[0].left;
  for(int i = 0; i < N-1; i++ )
    {
    merge[i] = T[i+1].left;
    merge[N-1+i] = T[i+1].right;
    height[i] = T[i+1].height;
    }
}

static inline mergetree_t *
convert_from_Rformat ( int N, int *merge, double *height, mergetree_t *T )
{
  if(T == NULL)
    T = alloc_mergetree(N);
  T[0].left = N;
  for(int i = 0; i < N-1; i++ )
    {
    T[i+1].left = merge[i];
    T[i+1].right = merge[N-1+i];
    T[i+1].height = height[i];
    }
  return T;
}

void
mergetree_bounding_leaf ( mergetree_t *T, int *ordering,
  int *l_oid, int *r_oid );

#endif /* _MERGETREE_H_ */
