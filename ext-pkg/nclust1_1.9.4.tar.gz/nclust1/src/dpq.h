/*
 * dpq.h - double-ended priority queue
 *
 * Implemented using interval heaps (van Leeuwen and Wood (1993) Comp J 36:209)
 *
 * - priority values are double-precision floating point numbers
 * - an arbitrary integer identifier is stored for each value (for searching
 *   and updating the queue through the identifiers)
 *
 * unique features: 
 * - search a node identified by (value,id) pair (return the heap position)
 * - remove a node (given a heap position)
 * These two are used to update a queue by removing items based on the
 * identifier efficiently (if the value is known).
 */

#ifndef _DPQ_H_
#define _DPQ_H_

#include <stdlib.h>
#include <math.h>

// The heap data structure is an array of this struct.
//
typedef struct
{
  double u, v;       // left and right value
  int a, b;          // item identifiers (left and right, respectively)
}
dpq_t;

// Q[0] is a sentinel, with interval value of [-INFINITY,+INFINITY]
//
// The indices are used to store the followings:
// Q[0].a is the number of items in the queue
//

static inline int
dpq_nitems (dpq_t *Q)
{ 
  return Q[0].a;
}

static inline int
dpq_nnodes ( dpq_t *Q )
{
  return (Q[0].a + 1)/2;
}

// Q[0].b is the number of allocated nodes (excluding the 0th)
//
static inline int
dpq_maxnodes (dpq_t *Q)
{
  return Q[0].b;
}

// allocate and initialize a queue
//
// The number of nodes (2 * number of items) are specified.
//
// the resulting memory can be released using free()
//
extern dpq_t *
dpq_alloc ( int maxnodes );

// initialize already allocated queue
//
static inline dpq_t *
dpq_init ( dpq_t *Q )
{
  if(!Q) return NULL;
  Q[0].u = -INFINITY;
  Q[0].v = INFINITY;
  Q[0].a = 0;
  return Q;
}

// get min and max values and ids
// when queue length == 1, the max is a bit tricky.
//
static inline double
dpq_min ( dpq_t *Q )
{
  return Q[1].u;
}

static inline int
dpq_imin ( dpq_t *Q )
{
  return Q[1].a;
}

static inline double
dpq_max( dpq_t *Q )
{
  return dpq_nitems(Q) > 1 ? Q[1].v: Q[1].u;
}

static inline int
dpq_imax( dpq_t *Q )
{
  return dpq_nitems(Q) > 1 ? Q[1].b: Q[1].a;
}

extern int                 // 0 if OK; else, node id of violating child
checkheap( dpq_t *Q, char *msg );

/*
 * 'low-level' operations for ensuring heap conditions are satisfied
 *  by exchanging values up or down the trees.
 *
 *  'i' is the node (interval) index. 'L' or 'R' correspond to the
 *  left or right bracket of the interval.
 */
extern void dpq_up_L ( dpq_t *Q, int i );
extern void dpq_up_R ( dpq_t *Q, int i );
extern void dpq_down_L (dpq_t *Q, int i );
extern void dpq_down_R (dpq_t *Q, int i );

// insert a new item, increasing the length of queue (unless the
// allocated memory limit is reached, where -1 is returned)
// if succesfull, return the new length of the queue
//
extern int dpq_insert ( dpq_t *Q, double x, int c );

// keeping the length constant, try to push a value to the 'min' ('max') end,
// discarding the item at the 'max' ('min') end.
// Nothing is done if the pushed item falls outside the opposite end.
//
extern int dpq_pushmin ( dpq_t *Q, double x, int c );
extern int dpq_pushmax ( dpq_t *Q, double x, int c );

// insert (if queue not full) or push (otherwise
//
static inline int
dpq_insertmin ( dpq_t *Q, double x, int c )
{
  if( Q[0].a >= 2*Q[0].b )
    return dpq_pushmin( Q, x, c );
  else
    return dpq_insert( Q, x, c );
}

static inline int
dpq_insertmax ( dpq_t *Q, double x, int c )
{
  if( Q[0].a >= 2*Q[0].b )
    return dpq_pushmax( Q, x, c );
  else
    return dpq_insert( Q, x, c );
}

// Find the node (interval) id and min/max location in the node, for
// a given pair of (value,item id). Typically the item id is unique,
// making the answer unique also (otherwise, the first one encountered
// in the tree traversal is returned).
//
extern void
dpq_search ( dpq_t *Q, double value, int id,
  int *node_, // pointer to the node 
  int *which_ // 0: left (min), 1: right (max)
  );

// Delete an item at a given node
//
// The last item is moved to the deleted position and then heap consistency is
// restored by the approriate exchange up and/or down
//

extern void dpq_delete_L ( dpq_t *Q, int node);
extern void dpq_delete_R ( dpq_t *Q, int node );

// remove an item specified by a value-id pair.
// return: 0 (if not found), or if found the node (interval) index.
// if which is supplied, 0 or 1 indicate left/right boundaries of the interval 
//
extern int dpq_remove( dpq_t *Q, double value, int id, int *which );
extern int dpq_relabel( dpq_t *Q, double value, int id, int new_id, int *which );


#endif /* _DPQ_H_ */
