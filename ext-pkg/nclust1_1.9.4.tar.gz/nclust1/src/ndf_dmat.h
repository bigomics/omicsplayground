/*
ndf_dmat.h - apply nclust() to clustering of dense data matrix

Those involving cor has an option to mean-center the vector of the
clustered object.

*/
#ifndef _DMAT_NCLUST_H_
#define _DMAT_NCLUST_H_

#include "mergetree.h"

// Usage: 
// first do mergetree_t *T = alloc_mergetree(n), then call
// dmat_nclust

void
dmat_nclust(
  int m,   // features 
  int n,   // items to be clustered
  double *x, // data matrix, features are contiguous in memory
  int centering, // 0: none, 1: mean center item,
                 // 2: mean center both item & feature
  int impute,   // 0: no imputation, 1: mean imputation
  int distance, // 0: Ward, 1: -zcorr, 2: Euclidean
  
  int link,  // tree link function
  mergetree_t *T
  );

// constants for options

// centering
#define NO_CENTERING 0
#define ITEM_CENTERING 1
#define FEATURE_CENTERING 2
#define BOTH_CENTERING 3

// distance
#define WARD_D 0   // 1 minus correlation
#define MZCOR 1   // minus z-transformed correlation
#define EUCLIDEAN 2 // Euclidean distance

// 'link' is defined in nclust.h

#endif // _DMAT_NCLUST_H_ 
