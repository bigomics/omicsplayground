/*
ndf_Rdist.c - R interface to use 'nclust' with data produced by
                R function 'dist'

*/

#include "nclust.h"
#include "branchflip.h"

// context for callback functions for dissimilarity measures
struct dist_context {
  int N;
  double *d; 
  int link;

  // for callback of branchflip
  int *nleaf; // number of items in subcluster
  int *alive; // flag if the index still used
  };

double dist_diss (int a, int b, void *ctx )
{
  struct dist_context *pw = (struct dist_context*)ctx;
  if( b < a )
    { int t = b; b = a; a = t; }
  return pw->d[ pw->N*(a-1) - a*(a-1)/2 + b-1 - 1];
}

void dist_bulk_diss ( int i, 
    int nreq, const int* B, const int *J, double *S, void *ctx )
{
  struct dist_context *pw = (struct dist_context*)ctx;
  i++;
  int N = pw->N;
  double *d = pw->d;
  for(int k = 0; k < nreq; k++ )
    {
    int a, b, bk = B[k]+1;
    if( i > bk )
      { a = bk; b = i; }
    else
      { a = i; b = bk; }
    S[J[k]] =  d[ N*(a-1) - a*(a-1)/2 + b-a - 1];
    }
}

int dist_merge (int a, int b, void *ctx )
{
  struct dist_context *pw = (struct dist_context*)ctx;

  if( a < 0 && b == 0 )
    return -a;
  if( a < 0 || b < 0 )
    return 0; // this should be an error
  if( a > b )
    { int t = a; a = b; b = t; }

  // combine (using average link for the moment, but we should put the
  // requested link inside the ctx)
  //
  int N = pw->N;
  double *D = pw->d;
  int *nleaf = pw->nleaf;
  for(int k = 1; k <= N; k++ )
    {
    if( pw->alive[k] == 0 || k == a || k == b ) continue;
    if( k < a && k < b )
      {
      int ka = N*(k-1) - k*(k-1)/2 + a-k - 1;
      int kb = N*(k-1) - k*(k-1)/2 + b-k - 1;
      D[kb] = nleaf[a]*D[ka] + nleaf[b]*D[kb];
      D[kb] /= nleaf[a]+ nleaf[b];
      }
    else if( k < b )
      {
      int ak = N*(a-1) - a*(a-1)/2 + k-a - 1;
      int kb = N*(k-1) - k*(k-1)/2 + b-k - 1;
      D[kb] = nleaf[a]*D[ak] + nleaf[b]*D[kb];
      D[kb] /= nleaf[a]+ nleaf[b];
      }
    else
      {
      int ak = N*(a-1) - a*(a-1)/2 + k-a - 1;
      int bk = N*(b-1) - b*(b-1)/2 + k-b - 1;
      D[bk] = nleaf[a]*D[ak] + nleaf[b]*D[bk];
      D[bk] /= nleaf[a]+ nleaf[b];
      }
    }
  nleaf[b] += nleaf[a];
  pw->alive[a] = 0;
  return b;
}

void 
dist_free (int a, void *ctx)
  {
  return;
  }

void 
Rdist_nclust(
  int *N_, double *pw, int *link, 
  int *branchflip,
  int *merge, double *height,
	int *order, int *leaf_level, int *branch_level )
{
  int N = *N_;
  struct dist_context ctx;
  ctx.N = N;
  ctx.d = pw;
  ctx.link = *link;
  
  ctx.nleaf = (int*)malloc(sizeof(int)*2*(N+1));
  ctx.alive = ctx.nleaf + N + 1;
  for(int i = 1; i <= N; i++ )
    ctx.nleaf[i] = ctx.alive[i] = 1;
  
  mergetree_t *T = alloc_mergetree(N);
  nclust( N, dist_bulk_diss, &ctx, *link, T );

	mergetree_sort ( T, NULL ); 

  if(*branchflip == 1 )
    nearest_nephew ( T, dist_merge, dist_diss, dist_free, &ctx );
  
  int maxlevel;
  mergetree_node_info ( T, order, leaf_level, branch_level, 0, 0, 0, &maxlevel );
  
  convert_to_Rformat ( T, merge, height );

  free(T); 
  free(ctx.nleaf);
}

